# MAA-v1 serialization specification for electronics-4597245

This document specifies the byte format evaluated by the revised manuscript dated 9 October 2026. The frozen schema, codec and vectors are copied without changing their bytes. The copied test script uses a local path for its legacy fixture so the attachment can be extracted anywhere. Their historical RC1/candidate labels identify the encoding checkpoint. They are not the name of the proposed construction in the manuscript.

## Framing and primitive types

Each object is u16le(domain length) || ASCII domain || u32le(field count) || repeated [u64le(field length) || field]. Nested objects retain their full framing. Fields occur in the exact order below. Objects are capped at 4 MiB, field count at 128 and domain length at 255. Integers have fixed unsigned little-endian widths: u8, u32, u64. b32 is exactly 32 bytes. Text is canonical UTF-8 NFC, 1 to 256 bytes; control characters U+0000–001F and U+007F–009F are rejected. Payloads are arbitrary bytes, at most 1 MiB. Expiry is nonzero Unix UTC seconds; period and versions are u64. Status is u8 (0 inactive, 1 active), with selected records required active.

Public matrices have 8*56*256 coefficients in row, column, polynomial-coefficient order, using unsigned canonical residues below q=17179859969 packed LSB-first at 34 bits, totaling 487424 bytes. Proofs have (16+56)*256 signed coefficients in polynomial/coefficient order, ZigZag-mapped and packed at 34 bits, totaling 78336 bytes. Reject out-of-range values, nonzero padding and trailing bytes. Verify the exact integer squared norm against floor(beta^2)=34631604178588811616. Signature fields contain 2420-byte ML-DSA-44 signatures; length alone does not validate a signature.

## Fixed object fields

The following table is copied from the accompanying schema.json. obj:name means a complete nested object. List and policy types are defined below.

| Domain | Ordered fields and types |
|---|---|
| MAA-v1/parameters | name: text; hmax: u32; n: u32; q: u64; d: u32; m0: u32; w: u32; gadget_radix: u32; gadget_digits: u32; pack_bits: u32; s_R: text; alpha: text; zeta: text; beta: text; preparation_budget: u64 |
| MAA-v1/setup-matrix | sid: b32; param_id: b32; seed: b32 |
| MAA-v1/dur-registration | sid: b32; param_id: b32; pid: b32; period: u64; expiry: u64; dur_version: u64 |
| MAA-v1/credential | sid: b32; param_id: b32; issuer: text; namespace: text; attribute: text; pid: b32; period: u64; matrix: public-matrix; root_version: u64; expiry: u64 |
| MAA-v1/leaf | credential: obj:credential; salt: b32 |
| MAA-v1/merkle-node | left: b32; right: b32 |
| MAA-v1/merkle-empty | sid: b32; param_id: b32; issuer: text; period: u64; root_version: u64 |
| MAA-v1/aa-root | sid: b32; param_id: b32; issuer: text; period: u64; root_version: u64; root: b32; leaf_count: u64; expiry: u64 |
| MAA-v1/public-root | sid: b32; param_id: b32; matrix: public-matrix |
| MAA-v1/selected | occurrence: b32; cid: b32; issuer: text; root_version: u64; status_version: u64; status: u8 |
| MAA-v1/selected-list | items: list:selected |
| MAA-v1/status | sid: b32; param_id: b32; issuer: text; period: u64; status_version: u64; cid: b32; status: u8; expiry: u64 |
| MAA-v1/manifest | sid: b32; param_id: b32; pid: b32; period: u64; policy_hash: b32; witness_hash: b32; selected: obj:selected-list; public_root_hash: b32; expiry: u64 |
| MAA-v1/request | verifier: text; nonce: b32; session: b32; resource: text; action: text; policy: policy; period: u64 |
| MAA-v1/message | sid: b32; param_id: b32; wid: b32; payload: payload; request: obj:request; salt: b32 |
| MAA-v1/token | sid: b32; param_id: b32; wid: b32; salt: b32; proof: proof |
| MAA-v1/signed-dur | statement: obj:dur-registration; signature: signature |
| MAA-v1/signed-credential | statement: obj:credential; signature: signature |
| MAA-v1/signed-root | statement: obj:aa-root; signature: signature |
| MAA-v1/signed-status | statement: obj:status; signature: signature |
| MAA-v1/opening | cid: b32; leaf_index: u64; leaf_count: u64; siblings: hash-list |

## Recursive policy and list types

- MAA-v1/policy-leaf: kind:u8=0, occurrence:b32, issuer:text, namespace:text, attribute:text.
- MAA-v1/policy-node: kind:u8 (1 AND, 2 OR), left:complete policy object, right:complete policy object. Children are strictly sorted by their complete canonical byte strings. Do not reassociate or simplify the formula. Policy depth is at most 16 and it has at most 64 unique leaf occurrences.
- MAA-v1/witness: first field count:u32, followed by count b32 occurrence fields. Count is 1 to 64 and occurrences are strictly increasing. An AND selects both children; an OR selects exactly one branch. Reject duplicates and unused leaves. No globally smallest satisfying branch is required.
- MAA-v1/selected-records (list:selected): first field count:u32, followed by complete selected objects, 1 to 64, strictly sorted by occurrence; reject repeated occurrence or credential identifiers. The selected-list wrapper has one field containing this complete list object.
- MAA-v1/siblings (hash-list): first field count:u32, followed by b32 sibling hashes, bottom to top, without sorting. Count is 0 to 32.

## Hashes, Merkle trees and randomness

SHA-256 hashes complete framed parameter, leaf, node, empty-root, public-root, manifest, policy and witness objects. A credential identifier is the salted leaf digest; the manifest identifier is its digest. SHAKE256 expands the complete setup-matrix object to 8*8*256 coefficients, and the message object to 8*256 coefficients. Parse unsigned 64-bit little-endian words x, reject x >= floor(2^64/q)*q, and emit x mod q. Preserve the stream prefix when extending output.

Merkle leaves are sorted unique credential identifiers. An odd final node duplicates itself. Empty roots hash their contextual merkle-empty object. A one-leaf root is its credential identifier. Signed roots authenticate leaf_count. Openings check leaf count, index, issuer, period, version, path length and required odd-node duplication.

DUR pseudonyms, issuance leaf salts and fresh signing salts are independent 256-bit CSPRNG draws; required RNG failure aborts. Fixed vector bytes are for deterministic codec checks. Vector signature fields are placeholders: the vectors are structural encoding examples, not accepted cryptographic authentication transcripts. Actual signature and protocol tests use the measured C++ implementation.

The signature layer signs complete dur-registration, aa-root and status statements, with trusted directory keys; signed-* wrappers only transport statement and signature. The signed-credential vector covers the optional direct-mode encoding; the measured profile uses batched roots. Before accepting a token, implementations authenticate the evidence, policy and selected occurrences, common context, versions and expiry, recompute the aggregate root and manifest digest, check nonce/session freshness, and verify the lattice equation and norm. The reference codec supplies byte encoding and checking, not this complete authorization workflow.

## Verification

Run `python -m unittest -v test_codec.py` and `python independent_layout_audit.py` in this extracted directory using Python 3.12 (standard library only). The second script independently verifies vector framing, hashes, ring mapping and packed coefficient order. The 23 object vectors and their checksums are listed in vectors/manifest.json. No performance experiments are rerun by these checks.
