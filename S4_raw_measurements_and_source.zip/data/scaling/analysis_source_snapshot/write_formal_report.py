from pathlib import Path
import csv,json,statistics,hashlib
P=Path(__file__).resolve().parent;R=Path((P/'latest_formal_run.txt').read_text(encoding='utf-8').strip())
a=json.loads((R/'independent_validation.json').read_text(encoding='utf-8'));assert a['status']=='PASS'
rows=list(csv.DictReader((R/'across_round_summary.csv').open()));index={(r['case_id'],r['phase']):r for r in rows}
paired=list(csv.DictReader((R/'paired_comparisons.csv').open()));ratios={(r['case_id'],r['comparison']):r for r in paired}
meta=json.loads((R/'run_metadata.json').read_text(encoding='utf-8'))
labels={'signer_prepare_trusted_capabilities':'签名方准备（已信任能力）','maa_online_sign':'MAA-v1 在线签名','maa_prepared_verify':'MAA-v1 缓存验证','maa_cold_verify':'MAA-v1 完整本地冷验证','cache_build_with_probe_verify':'验证缓存构建（含 probe）','mldsa_attribute_sign':'逐属性 ML-DSA 签名','mldsa_attribute_verify':'逐属性 ML-DSA 验证','mldsa_periodic_sign':'单周期 ML-DSA 签名','mldsa_periodic_verify':'单周期 ML-DSA 验证'}
def fmt(r):return f"{float(r['median_of_round_medians_ms']):.3f} [{float(r['bootstrap95_low_ms']):.3f}, {float(r['bootstrap95_high_ms']):.3f}]"
lines=['# MAA-v1 RC1 正式研究测量报告','',f"数据目录：{R}",'',f"运行机器：{meta['cpu']['Name']}；独立进程轮次 10；每轮 23 用例。每常规阶段每用例 30 个正式样本、5 次 warmup；每种刷新每轮 1 次。",'',f"总计 {a['raw_rows_including_warmup']:,} 条原始记录，其中正式观测 {a['measured_rows']:,} 条、warmup {a['warmup_rows']:,} 条。记录中的失败数 {a['recorded_failure_rows']}，所有轮次完整通过；这不是零真实失败概率的保证。",'', '## k=64、64 个 authority 的结果','', '单位 ms；数值为 10 个轮次中位数的中位数；方括号为以独立轮次重采样的 percentile bootstrap 95% 区间。','', '| 阶段 | 中位数 [95% 区间] |','|---|---:|']
for phase,label in labels.items():lines.append(f"| {label} | {fmt(index['XD_K64',phase])} |")
lines+=['','## 同轮配对比较','', '| k=64 比较 | MAA-v1 / 对照 | 95% 区间 |','|---|---:|---:|']
for comp,label in [('sign_vs_attribute','在线签名 / 逐属性签名'),('verify_vs_attribute','缓存验证 / 逐属性验证'),('sign_vs_periodic','在线签名 / 单周期签名'),('verify_vs_periodic','缓存验证 / 单周期验证')]:
 r=ratios['XD_K64',comp];lines.append(f"| {label} | {float(r['median_paired_ratio']):.3f} | [{float(r['bootstrap95_low']):.3f}, {float(r['bootstrap95_high']):.3f}] |")
normal=list(csv.DictReader((R/'round_normalized_scaling.csv').open()))
endpoint=next(r for r in normal if r['case_id']=='XD_K64' and r['phase']=='maa_online_sign')
lines+=['', '## 扩展性解释', '', f"k=64 相对同轮 k=1 的在线签名中位数比值为 {float(endpoint['median_within_round_ratio']):.4f}，95% 区间 [{float(endpoint['bootstrap95_low']):.4f}, {float(endpoint['bootstrap95_high']):.4f}]。该区间高于 1，说明本次研究路径存在小幅端点开销，不能写成严格常数耗时或直接沿用旧图的 0.959--1.000 范围。证明维度固定不等于完整编码与上下文处理成本恒定；原因需要分阶段测量才能进一步确定。"]
lines+=['','比值先在同一轮内计算，再跨轮统计；不能用表中聚合耗时的直接相除替代。','', '## 实测 token 通信','', '以下只比较实际编码 token，公共 request/payload、凭证目录及冷支持材料单独计数。ML-DSA 使用新测量 framing，因此不沿用旧 baseline 字节公式。','', '| 属性数 | MAA-v1 token (B) | 逐属性 ML-DSA token (B) | 单周期 ML-DSA token (B) |','|---|---:|---:|---:|']
for k in [1,32,33,64]:
 cid=f'XD_K{k:02d}';values=[int(index[cid,phase]['object_bytes_min']) for phase in ['maa_online_sign','mldsa_attribute_sign','mldsa_periodic_sign']];lines.append('| '+str(k)+' | '+' | '.join(map(str,values))+' |')
bytes64=int(index['XD_K64','mldsa_attribute_sign']['object_bytes_min']);reduction=(1-78522/bytes64)*100
lines+=['',f'k=64 时 MAA-v1 token 相对本轮逐属性 ML-DSA token 减少 {reduction:.2f}%。这不是完整冷启动流量的节省比例。','', '## 版本刷新与分组','', '| 用例 | 状态更新增量 (B) | 根更新增量 (B) |','|---|---:|---:|']
for cid in ['XD_K64','SINGLE_K64','FW64_J08']:
 lines.append(f"| {cid} | {index[cid,'refresh_status_issuer_update']['object_bytes_min']} | {index[cid,'refresh_root_issuer_update']['object_bytes_min']} |")
lines+=['','460 项刷新增量检查由导出的实际对象长度独立重算，共享根去重；每一轮内，固定 64 属性、不同 authority 分组的公开聚合根均一致（共 10 轮）。该一致性不是耗时相等的结论。','', '## 数据文件与边界','', '- across_round_summary.csv：所有阶段的逐用例跨轮结果。','- paired_comparisons.csv：同轮耗时比值及区间。','- round_normalized_scaling.csv：相对各轮 k=1 的归一化结果。','- refresh_increment_audit.csv 与 independent_validation.json：字节、完整性及来源审查。','- formal_signing_scaling、formal_token_bytes：如已生成，PNG/PDF 科研图。','', '本轮数据来自当前 Intel 主机，不能与旧 Ryzen 主机耗时直接拼接。固定阶段/用例顺序，Windows 调度和 CPU 调频未隔离；进程峰值内存是整轮累计高水位，且该进程同时持有本方案状态与对照密钥，不能据此比较各算法独立内存。能力矩阵沿用固定研究抽样种子，结果条件于该测试凭证样本；每轮公开 setup、签名和请求随机数重新生成。缓存构建包含完整 probe 验证与再次聚合；签名准备从已信任能力开始。目录、网络、HSM 与分布式撤销未测量。研究浮点 sampler、自适应 witness 概率证明边界继续保留，性能通过不构成安全审计。','', '原稿冻结表格暂保留。本报告与可复核的新数据用于下一步统一更新正文表格、图与审稿回复，避免只替换 token 长度而保留旧耗时。']
for row in rows:
    if row['phase']=='mldsa_attribute_sign':assert int(row['object_bytes_min'])==int(row['object_bytes_max'])==121+2428*int(row['witness_size'])
    if row['phase']=='mldsa_periodic_sign':assert int(row['object_bytes_min'])==int(row['object_bytes_max'])==2544
lines+=['','## Token 字节公式与图表','','本轮逐属性基线 token 的精确长度为 121+2428k 字节（含测量 framing），单周期基线为 2544 字节。全部用例输出与该公式一致，因此本轮 token 层的严格交叉点为 k=33。该结论不包含公共 request/payload 或冷支持对象。','',f"![签名耗时及轮内归一化结果]({(R/'formal_signing_scaling.png').as_posix()})",'',f"![实测 token 字节]({(R/'formal_token_bytes.png').as_posix()})"]
(R/'正式研究测量报告.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
files=[P/x for x in ['analyze_formal.py','plot_formal.py','write_formal_report.py']]
(R/'analysis_source_sha256.json').write_text(json.dumps({str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in files},indent=2),encoding='utf-8')
print('FORMAL_REPORT_WRITTEN='+str(R/'正式研究测量报告.md'))
