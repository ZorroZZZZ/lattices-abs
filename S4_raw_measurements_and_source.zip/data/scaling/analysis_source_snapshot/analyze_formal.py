"""Audit complete rounds and summarize round-level medians; never mix pilot and formal data."""
from pathlib import Path
import argparse,csv,json,math,hashlib,statistics,random
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--run',type=Path);args=parser.parse_args()
R=args.run or Path((P/'latest_formal_run.txt').read_text(encoding='utf-8').strip())
meta=json.loads((R/'run_metadata.json').read_text(encoding='utf-8'))
assert meta['mode']=='formal' and meta['status']=='PASS' and meta['formal_collection_complete']
cfg=meta['configuration']['formal'];cases=list(csv.DictReader((R/'source_snapshot'/cfg['matrix']).open()))
assert len(cases)==23 and cfg['rounds']==10
for filename,digest in meta['source_sha256'].items():
    f=Path(filename);assert f.exists() and hashlib.sha256(f.read_bytes()).hexdigest()==digest,filename
ordinary={'signer_prepare_trusted_capabilities','maa_online_sign','cache_build_with_probe_verify','maa_prepared_verify','maa_cold_verify','mldsa_attribute_sign','mldsa_attribute_verify','mldsa_periodic_sign','mldsa_periodic_verify'}
refresh={'refresh_status_issuer_update','refresh_root_issuer_update','refresh_status_signer_prepare','refresh_root_signer_prepare','refresh_status_cache_with_probe','refresh_root_cache_with_probe'}
phases=ordinary|refresh
allrows=[];grouped={};sizes={};increments=[];source_hashes={}
for rid in range(cfg['rounds']):
    folder=R/f'round_{rid:02d}';assert 'BENCHMARK_DRIVER=PASS cases=23 preparations=874' in (folder/'driver.log').read_text(encoding='utf-8');rows=list(csv.DictReader((folder/'raw.csv').open()))
    assert len(rows)==len(cases)*(len(ordinary)*(cfg['warmups']+cfg['trials'])+len(refresh))
    assert {r['case_id'] for r in rows}=={c['case_id'] for c in cases}
    assert all(int(r['round'])==rid and r['ok']=='1' and math.isfinite(float(r['ms'])) and float(r['ms'])>=0 for r in rows)
    for case in cases:
        cid=case['case_id'];selected=[r for r in rows if r['case_id']==cid]
        assert {r['phase'] for r in selected}==phases
        for phase in phases:
            active=[r for r in selected if r['phase']==phase and r['warmup']=='0']
            warm=[r for r in selected if r['phase']==phase and r['warmup']=='1']
            assert len(active)==(1 if phase in refresh else cfg['trials'])
            assert len(warm)==(0 if phase in refresh else cfg['warmups'])
            assert sorted(int(x['trial']) for x in active)==(list(range(cfg['trials'])) if phase in ordinary else [0])
            assert sorted(int(x['trial']) for x in warm)==list(range(-cfg['warmups'],0)) if phase in ordinary else not warm
            grouped[rid,cid,phase]=statistics.median(float(x['ms']) for x in active)
            sizes.setdefault((cid,phase),set()).update(int(x['object_bytes']) for x in active)
        assert sizes[cid,'maa_online_sign']=={78522}
        casedir=folder/cid;issuer=list(casedir.glob('issuer_*'));assert len(issuer)==int(case['witness_size'])
        manifest=(casedir/'manifest.bin').stat().st_size
        status={(d/'signed-status.bin').read_bytes() for d in issuer};roots={(d/'signed-root.bin').read_bytes() for d in issuer}
        statusbytes=manifest+sum(map(len,status))
        rootbytes=statusbytes+sum(map(len,roots))+sum((d/'leaf.bin').stat().st_size+(d/'opening.bin').stat().st_size for d in issuer)
        assert sizes[cid,'refresh_status_issuer_update']=={statusbytes}
        assert sizes[cid,'refresh_root_issuer_update']=={rootbytes}
        increments.append({'round':rid,'case_id':cid,'status_increment_bytes':statusbytes,'root_increment_bytes':rootbytes})
        assert (casedir/'research_sampler_seed.txt').exists()
    # Fixed witness partitioning must preserve the public matrix within the round.
    fixed={hashlib.sha256((folder/c['case_id']/'public-root.bin').read_bytes()).hexdigest() for c in cases if c['case_id'].startswith('FW64_')}
    assert len(fixed)==1
    source_hashes[str(folder/'raw.csv')]=hashlib.sha256((folder/'raw.csv').read_bytes()).hexdigest()
    allrows.extend(rows)
assert len(allrows)==73830
rng=random.Random(20261008)
def percentile(a,p):
    a=sorted(a);position=(len(a)-1)*p;lo=int(position);hi=min(lo+1,len(a)-1);return a[lo]+(a[hi]-a[lo])*(position-lo)
def interval(values):
    boot=[statistics.median(rng.choices(values,k=len(values))) for _ in range(10000)]
    return percentile(boot,.025),percentile(boot,.975)
def write(name,rows):
    with (R/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary=[]
for case in cases:
    cid=case['case_id']
    for phase in sorted(phases):
        values=[grouped[r,cid,phase] for r in range(10)];low,high=interval(values)
        summary.append(dict(case_id=cid,witness_size=case['witness_size'],participating_authorities=case['participating_authorities'],phase=phase,independent_rounds=10,samples_per_round=1 if phase in refresh else 30,median_of_round_medians_ms=statistics.median(values),bootstrap95_low_ms=low,bootstrap95_high_ms=high,min_round_median_ms=min(values),max_round_median_ms=max(values),object_bytes_min=min(sizes[cid,phase]),object_bytes_max=max(sizes[cid,phase])))
write('across_round_summary.csv',summary);write('refresh_increment_audit.csv',increments)
comparisons=[]
for case in cases:
    cid=case['case_id']
    for label,num,den in [('sign_vs_attribute','maa_online_sign','mldsa_attribute_sign'),('verify_vs_attribute','maa_prepared_verify','mldsa_attribute_verify'),('sign_vs_periodic','maa_online_sign','mldsa_periodic_sign'),('verify_vs_periodic','maa_prepared_verify','mldsa_periodic_verify')]:
        ratios=[grouped[r,cid,num]/grouped[r,cid,den] for r in range(10)];low,high=interval(ratios)
        comparisons.append(dict(case_id=cid,comparison=label,median_paired_ratio=statistics.median(ratios),bootstrap95_low=low,bootstrap95_high=high))
write('paired_comparisons.csv',comparisons)
normalized=[]
for case in cases:
    if not case['case_id'].startswith('XD_'):continue
    cid=case['case_id']
    for phase in ['maa_online_sign','maa_prepared_verify','mldsa_attribute_sign','mldsa_periodic_sign']:
        ratios=[grouped[r,cid,phase]/grouped[r,'XD_K01',phase] for r in range(10)];low,high=interval(ratios)
        normalized.append(dict(case_id=cid,witness_size=int(case['witness_size']),phase=phase,median_within_round_ratio=statistics.median(ratios),bootstrap95_low=low,bootstrap95_high=high))
write('round_normalized_scaling.csv',normalized)
validation={'status':'PASS','run':str(R),'independent_rounds':10,'cases_per_round':23,'raw_rows_including_warmup':len(allrows),'measured_rows':sum(r['warmup']=='0' for r in allrows),'warmup_rows':sum(r['warmup']=='1' for r in allrows),'recorded_failure_rows':sum(r['ok']!='1' for r in allrows),'incremental_refresh_checks':460,'fixed_witness_partition_checks':10,'token_bytes':78522,'bootstrap':{'replicates':10000,'seed':20261008,'unit':'independent process round, median statistic','method':'percentile; paired ratios before resampling'},'cpu':meta['cpu'],'source_identity':'PASS','raw_sha256':source_hashes,'limits':['research floating-point sampler','fixed stage/case order and unpinned Windows scheduling','process cumulative peak WorkingSet','trusted local currentness register; no network/directory measurements','cache build includes full authentication probe and repeat public-root build','signer prepare starts from trusted capability objects','refresh has one observation per case per round','no production-security or adaptive-availability certificate']}
(R/'independent_validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
print('FORMAL_INDEPENDENT_AUDIT=PASS rounds=10 cases=23 raw_rows=73830 refresh_checks=460')
print('FORMAL_ANALYSIS_OUTPUT='+str(R))
