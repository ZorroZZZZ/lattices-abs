"""Static research figures from independent round summaries; matplotlib only."""
from pathlib import Path
import csv,json,os
os.environ.setdefault('MPLCONFIGDIR',r'D:/codex/tmp/matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;R=Path((P/'latest_formal_run.txt').read_text(encoding='utf-8').strip())
assert json.loads((R/'independent_validation.json').read_text(encoding='utf-8'))['status']=='PASS'
rows=list(csv.DictReader((R/'across_round_summary.csv').open()));norm=list(csv.DictReader((R/'round_normalized_scaling.csv').open()))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':140,'savefig.dpi':300,'pdf.fonttype':42})
colors=['#1769aa','#cf6b18','#378449'];styles=[('maa_online_sign','MAA-v1 RC1'),('mldsa_attribute_sign','Per-attribute ML-DSA'),('mldsa_periodic_sign','Periodic ML-DSA')]
fig,axes=plt.subplots(1,2,figsize=(10.5,3.7),layout='constrained')
for color,(phase,label) in zip(colors,styles):
 data=sorted([r for r in rows if r['case_id'].startswith('XD_') and r['phase']==phase],key=lambda r:int(r['witness_size']))
 x=[int(r['witness_size']) for r in data];y=[float(r['median_of_round_medians_ms']) for r in data];lo=[float(r['bootstrap95_low_ms']) for r in data];hi=[float(r['bootstrap95_high_ms']) for r in data]
 axes[0].plot(x,y,'o-',color=color,label=label,markersize=3);axes[0].fill_between(x,lo,hi,color=color,alpha=.14)
 data=sorted([r for r in norm if r['phase']==phase],key=lambda r:int(r['witness_size']));x=[int(r['witness_size']) for r in data];y=[float(r['median_within_round_ratio']) for r in data]
 axes[1].plot(x,y,'o-',color=color,label=label,markersize=3);axes[1].fill_between(x,[float(r['bootstrap95_low']) for r in data],[float(r['bootstrap95_high']) for r in data],color=color,alpha=.14)
# The shared log scale can hide the small RC1 increase; show its full interval separately.
zoom=axes[1].inset_axes([.50,.26,.46,.30])
data=sorted([r for r in norm if r['phase']=='maa_online_sign'],key=lambda r:int(r['witness_size']))
x=[int(r['witness_size']) for r in data]
zoom.plot(x,[float(r['median_within_round_ratio']) for r in data],'o-',color=colors[0],markersize=2)
zoom.fill_between(x,[float(r['bootstrap95_low']) for r in data],[float(r['bootstrap95_high']) for r in data],color=colors[0],alpha=.18)
zoom.axhline(1,color='gray',linestyle='--',linewidth=.7);zoom.set_ylim(.96,1.04);zoom.set_xticks([1,32,64]);zoom.set_yticks([.98,1,1.02]);zoom.tick_params(labelsize=7);zoom.set_title('MAA-v1 detail',fontsize=8);zoom.grid(alpha=.2)
axes[0].set(ylabel='Prepared request signing (ms)',xlabel='Selected attributes',yscale='log');axes[1].set(ylabel='Within-round ratio to k=1',xlabel='Selected attributes',yscale='log')
for ax in axes:ax.grid(alpha=.2);ax.set_xticks([1,8,16,32,48,64])
axes[0].legend(frameon=False,fontsize=8);fig.suptitle('Intel i9-14900HX; 10 process rounds; research sampler',fontsize=11)
for suffix in ['png','pdf']:fig.savefig(R/('formal_signing_scaling.'+suffix))
plt.close(fig)
fig,ax=plt.subplots(figsize=(6.8,3.6),layout='constrained')
for color,(phase,label) in zip(colors,styles):
 data=sorted([r for r in rows if r['case_id'].startswith('XD_') and r['phase']==phase],key=lambda r:int(r['witness_size']))
 ax.plot([int(r['witness_size']) for r in data],[int(r['object_bytes_min'])/1024 for r in data],'o-',color=color,label=label,markersize=4)
ax.set(xlabel='Selected attributes',ylabel='Encoded request token (KiB)',title='Measured token bytes; excludes shared request and cold support')
ax.grid(alpha=.2);ax.legend(frameon=False,fontsize=9)
for suffix in ['png','pdf']:fig.savefig(R/('formal_token_bytes.'+suffix))
plt.close(fig)
print('FORMAL_FIGURES=PASS png=2 pdf=2')
