// Research timing driver. Algebraic checks are outside measured signing intervals.
#define MAA_CODEC_NO_MAIN
#include "maa_profile.cpp"
namespace bench {
using namespace maa;
using Clock=std::chrono::steady_clock;
static int trials=3,warmups=1,round_id=0;
static std::string case_id;
static fs::path case_dir;
static Fields cached_cids;
static std::ofstream raw;
static double elapsed(Clock::time_point t){return std::chrono::duration<double,std::milli>(Clock::now()-t).count();}
static void record(int trial,const char*phase,double ms,uint64_t bytes,bool ok){raw<<round_id<<","<<case_id<<","<<trial<<","<<(trial<0)<<","<<phase<<","<<std::setprecision(12)<<ms<<","<<bytes<<","<<peak_rss_bytes()<<","<<ok<<"\n";raw.flush();require(ok,"benchmark operation failed");}
static Fields support(const SmokeState&s){Fields v{s.manifest,s.witness,s.setup,enc("signed-dur",{s.dur,s.dur_sig}),s.dur_key.pk};for(const auto&r:s.presented){v.push_back(r.leaf);v.push_back(r.opening);v.push_back(enc("signed-root",{r.root,r.root_sig}));v.push_back(enc("signed-status",{r.status,r.status_sig}));v.push_back(r.issuer_key.pk);}return v;}
static uint64_t changed_bytes(const Fields&before,const Fields&after){std::set<Bytes>old(before.begin(),before.end()),fresh(after.begin(),after.end());uint64_t n=0;for(const auto&b:fresh)if(!old.count(b))n+=b.size();return n;}
struct Prepared {RootInst root;Bytes wid,sid,param,pid,policy;uint64_t period,root_version,status_version,expiry;std::set<Bytes>consumed;};
static Prepared cache(SmokeState&s,const MatU&A,const Bytes&probe){auto request=parse(s.request).f;s.consumed.erase(request[1]);require(smoke_verify(s,probe,s.request,s.payload,uint64_t(std::time(nullptr))),"cache authentication probe");return {public_root(A,s.presented),sha(s.manifest),s.sid,s.param,s.pid,s.policy,s.period,s.root_version,s.status_version,value(parse(s.manifest).f[8]),{}};}
static bool prepared_verify(const SmokeState&s,Prepared&v,const Bytes&token){try{validate("token",token);validate("request",s.request);auto t=parse(token).f,r=parse(s.request).f;require(s.sid==v.sid&&s.param==v.param&&s.pid==v.pid&&s.period==v.period&&s.root_version==v.root_version&&s.status_version==v.status_version&&sha(s.manifest)==v.wid,"cache currentness");require(t[0]==v.sid&&t[1]==v.param&&t[2]==v.wid&&value(r[6])==v.period&&r[5]==v.policy&&v.expiry>uint64_t(std::time(nullptr)),"prepared context");require(!v.consumed.count(r[1]),"prepared replay");auto msg=enc("message",{v.sid,v.param,v.wid,s.payload,s.request,t[3]});require(M_times_vec(v.root,proof_value(t[4]))==target(msg),"prepared relation");v.consumed.insert(r[1]);return true;}catch(...){return false;}}
static Bytes request(const SmokeState&s){return enc("request",{str("PDP-1"),random32(),random32(),str("/record"),str("read"),s.policy,ui(s.period,8)});}
static Bytes sign(SmokeState&s,const RootInst&root,const EvalTW&te,const Schur&schur,DZ&dz,VecI&proof){
 auto salt=random32();auto msg=enc("message",{s.sid,s.param,sha(s.manifest),s.payload,s.request,salt});auto u=target(msg);RecStats stats;
 auto p=sample_perturb(dz,te,schur,stats);auto mp=M_times_vec(root,p);std::vector<PolyU>v(D);for(int i=0;i<D;i++)for(int j=0;j<N;j++)v[i][j]=sub_mod(u[i][j],mp[i][j]);
 auto z=module_gsample(dz,v);auto tz=T_times_z_exact(root.T,z);proof=VecI(ROOT_WIDTH);
 for(int i=0;i<M0;i++)for(int j=0;j<N;j++)proof[i][j]=p[i][j]+tz[i][j];for(int i=0;i<W;i++)for(int j=0;j<N;j++)proof[M0+i][j]=p[M0+i][j]+z[i][j];
 return enc("token",{s.sid,s.param,sha(s.manifest),salt,proof_bytes(proof)});
}
static void reprepare(SmokeState&s,const MatU&A,const std::vector<Credential>&caps,int trial,const char*phase){auto start=Clock::now();reserve_preparation();auto root=aggregate_credentials(A,caps,int(caps.size()));require(exact_trapdoor_gate(root.T),"prepare exact gate");auto te=transform_T(root.T);require(aggregate_trapdoor_admissible(te,nullptr,admissibility_threshold()),"prepare floating gate");auto schur=build_schur(te);auto digest=sha(enc("public-root",{s.sid,s.param,matrix_bytes(root.Bpub)}));auto manifest=make_manifest(s,digest,parse(s.manifest).f[8]);auto ms=elapsed(start);require(manifest==s.manifest&&verify_root_identity(root),"reprepare state");record(trial,phase,ms,0,true);}
static Bytes baseline_context(const SmokeState&s){return sha(frame("MAA-bench/context",{s.sid,s.param,s.pid,sha(s.policy),sha(s.witness),s.request,s.payload}));}
static void baseline(SmokeState&s,const std::vector<MLDKey>&keys,int trial,bool periodic){
 auto start=Clock::now();auto context=baseline_context(s);Fields sigs;size_t count=periodic?1:keys.size();
 for(size_t i=0;i<count;i++){auto msg=periodic?frame("MAA-bench/periodic",{context}):frame("MAA-bench/attribute",{context,s.presented[i].occurrence,cached_cids[i]});sigs.push_back(mld_sign(msg,keys[i],true));}
 auto token=frame(periodic?"MAA-bench/periodic-token":"MAA-bench/per-attribute-token",{context,listing("MAA-bench/signatures",sigs)});record(trial,periodic?"mldsa_periodic_sign":"mldsa_attribute_sign",elapsed(start),token.size(),true);
 start=Clock::now();auto parsed=parse(token);auto verifycontext=baseline_context(s);auto decoded=list(parsed.f[1],"MAA-bench/signatures",64);bool ok=parsed.f[0]==verifycontext&&decoded.size()==count;
 for(size_t i=0;i<count;i++){auto msg=periodic?frame("MAA-bench/periodic",{verifycontext}):frame("MAA-bench/attribute",{verifycontext,s.presented[i].occurrence,cached_cids[i]});ok=ok&&mld_verify(msg,decoded[i],keys[i]);}record(trial,periodic?"mldsa_periodic_verify":"mldsa_attribute_verify",elapsed(start),token.size(),ok);
 auto corrupted=sigs[0];corrupted[0]^=1;auto msg=periodic?frame("MAA-bench/periodic",{context}):frame("MAA-bench/attribute",{context,s.presented[0].occurrence,cached_cids[0]});require(!mld_verify(msg,corrupted,keys[0]),"baseline tamper accepted");
}
static void hook(SmokeState&s,const MatU&A,const std::vector<Credential>&caps,const RootInst&root,const EvalTW&te,const Schur&schur,std::mt19937_64&rng){
 cached_cids.clear();for(const auto&rec:s.presented)cached_cids.push_back(sha(rec.leaf));auto support_bytes=cold_support_bytes(s);auto saved_request=s.request;auto saved_consumed=s.consumed;auto seed_bytes=random32();auto sampler_seed=value(Bytes(seed_bytes.begin(),seed_bytes.begin()+8));std::mt19937_64 sample_rng(sampler_seed);DZ dz(sample_rng);std::ofstream seedfile(case_dir/"research_sampler_seed.txt");seedfile<<sampler_seed<<"\n";std::vector<MLDKey>keys;for(size_t i=0;i<caps.size();i++)keys.push_back(real_key());Prepared prepared;Bytes lasttoken;VecI proof;
 for(int i=-warmups;i<trials;i++){
  reprepare(s,A,caps,i,"signer_prepare_trusted_capabilities");s.request=request(s);
  auto start=Clock::now();auto token=sign(s,root,te,schur,dz,proof);record(i,"maa_online_sign",elapsed(start),token.size(),true);
  // Algebra and norm assertions are deliberately outside the measured signing interval.
  auto t=parse(token).f;auto msg=enc("message",{s.sid,s.param,t[2],s.payload,s.request,t[3]});require(M_times_vec(root,proof)==target(msg),"post-sign algebra");validate("token",token);
  start=Clock::now();prepared=cache(s,A,token);record(i,"cache_build_with_probe_verify",elapsed(start),support_bytes,true);
  start=Clock::now();bool ok=prepared_verify(s,prepared,token);record(i,"maa_prepared_verify",elapsed(start),token.size(),ok);require(!prepared_verify(s,prepared,token),"prepared replay accepted");
  s.consumed.erase(parse(s.request).f[1]);start=Clock::now();ok=smoke_verify(s,token,s.request,s.payload,uint64_t(std::time(nullptr)));record(i,"maa_cold_verify",elapsed(start),support_bytes+token.size()+s.request.size()+s.payload.size(),ok);
  baseline(s,keys,i,false);baseline(s,keys,i,true);lasttoken=token;
 }
 // A trusted current-version register invalidates the cache before any new request can pass.
 prepared.consumed.clear();s.status_version++;require(!prepared_verify(s,prepared,lasttoken),"stale cache accepted");s.status_version--;
 auto public_digest=parse(s.manifest).f[7];
 for(int stage=0;stage<2;stage++){
  SmokeState updated=s;auto before=support(updated);auto start=Clock::now();auto expiry=parse(updated.manifest).f[8];
  if(stage==0){updated.status_version++;for(auto&rec:updated.presented){auto fields=parse(rec.status).f;fields[4]=ui(updated.status_version,8);rec.status=enc("status",fields);rec.status_sig=mld_sign(rec.status,rec.issuer_key,true);}}
  else{updated.root_version++;for(auto&rec:updated.presented){auto fields=parse(rec.credential).f;fields[8]=ui(updated.root_version,8);rec.credential=enc("credential",fields);rec.leaf=enc("leaf",{rec.credential,random32()});}authenticate_issuer_trees(updated,0);}
  updated.manifest=make_manifest(updated,public_digest,expiry);auto update_ms=elapsed(start);auto bytes=changed_bytes(before,support(updated));record(0,stage==0?"refresh_status_issuer_update":"refresh_root_issuer_update",update_ms,bytes,true);
  reprepare(updated,A,caps,0,stage==0?"refresh_status_signer_prepare":"refresh_root_signer_prepare");updated.request=request(updated);auto token=sign(updated,root,te,schur,dz,proof);require(!smoke_verify(updated,lasttoken,updated.request,updated.payload,uint64_t(std::time(nullptr))),"refresh old token accepted");
  start=Clock::now();auto fresh=cache(updated,A,token);record(0,stage==0?"refresh_status_cache_with_probe":"refresh_root_cache_with_probe",elapsed(start),bytes,true);require(prepared_verify(updated,fresh,token),"refresh new token rejected");
  auto dir=case_dir/(stage==0?"refresh_status":"refresh_root");fs::create_directories(dir);write(dir/"manifest.bin",updated.manifest);write(dir/"token.bin",token);write(dir/"request.bin",updated.request);
 }
 for(auto&key:keys)SecureZeroMemory(key.sk.data(),key.sk.size());s.request=saved_request;s.consumed=saved_consumed;
}
}
int main(int argc,char**argv){try{maa::require(argc==6,"usage: maa_benchmark matrix.csv output trials warmups round");bench::trials=std::stoi(argv[3]);bench::warmups=std::stoi(argv[4]);bench::round_id=std::stoi(argv[5]);maa::require(bench::trials>=1&&bench::warmups>=0,"sample counts");fs::path out=argv[2];fs::create_directories(out);bench::raw.open(out/"raw.csv");maa::require(bool(bench::raw),"raw output");bench::raw<<"round,case_id,trial,warmup,phase,ms,object_bytes,process_peak_working_set_bytes,ok\n";maa::benchmark_hook=bench::hook;std::ifstream matrix(argv[1]);maa::require(bool(matrix),"matrix input");std::string line;std::getline(matrix,line);int count=0;while(std::getline(matrix,line)){if(line.empty())continue;std::replace(line.begin(),line.end(),',',' ');std::istringstream row(line);int k,p;size_t leaves;maa::require(bool(row>>bench::case_id>>k>>p>>leaves),"matrix row");bench::case_dir=out/bench::case_id;std::cout<<"BENCH_BEGIN="<<bench::case_id<<std::endl;maa::lattice_smoke(k,bench::case_dir,p,leaves,false,false,false);count++;}std::cout<<"BENCHMARK_DRIVER=PASS cases="<<count<<" preparations="<<preparation_counter<<std::endl;return 0;}catch(const std::exception&e){std::cerr<<"BENCHMARK_FAIL: "<<e.what()<<std::endl;return 21;}}
