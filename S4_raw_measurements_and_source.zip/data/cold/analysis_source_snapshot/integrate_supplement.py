from pathlib import Path
import csv,json,re,shutil,datetime
P=Path(__file__).resolve().parent; run=Path((P/'latest_supplement_formal_run.txt').read_text().strip());base=P.parent
assert json.loads((run/'supplement_validation.json').read_text())['status']=='PASS'
rows=list(csv.DictReader((run/'supplement_summary.csv').open()));v={(r['case_id'],r['phase']):float(r['median_of_process_medians_ms']) for r in rows};cases=list(csv.DictReader((run/'source_snapshot/correctness_matrix.csv').open()))
def n(phase):return f"{v[('XD_K64',phase)]:.3f}"
section=r'''\subsection{Supplemental Complete Local Preparation and Sampling Components}
\label{sec:supplement-cold}
A separate five-process batch uses the same 23 benchmark cases (20 distinct witness/authority-count pairs, including repeated endpoints), Intel/MSVC host, RC1 profile, and research sampler. Each process measures ten ordinary iterations after two warmups, and three iterations of each refresh stage after one warmup. All 14,720 observations, including 11,960 measured observations, pass the recorded checks. Results below are medians of process medians. Capability coefficients use the original fixed-seed datasets; independent processes are timing replicates, not independently sampled secret populations. Five independent processes give limited precision; the batch is not pooled with the original ten-round data for paired comparisons.

Complete local cold signer preparation authenticates DUR/issuer signatures, Merkle/status evidence, policy/witness and manifest binding, checks each capability's public matrix against its authenticated credential, aggregates the private capabilities, checks the aggregate trapdoor identity and both gates, and constructs sampler transforms and Schur data. It checks the aggregate secret relation rather than recomputing each individual trapdoor identity. Cold signer total adds a fresh signature and canonical encoding. Inputs, private capabilities, and trusted keys are memory-resident: network retrieval, disk, initial issuance, and trust-anchor provisioning are excluded.

Pure verifier preparation authenticates public evidence and constructs the root/cache without a probe-token verification. Timed outputs are checked outside the intervals by the original complete verifier. Negative checks reject DUR/root/status signature tampering, wrong versions, replay, and stale refreshed caches. Tokens remain 78,522 bytes.

\begin{table}[H]
\caption{Supplemental local cold-path costs (milliseconds): five processes, ten measurements per configuration/process.}
\label{tab:supplement-cold}\centering\scriptsize
\begin{tabular}{rrrrrr}
\toprule $k$ & AAs & Cold signer prep. & Cold signer total & Pure verifier prep. & Prepared verify\\\midrule
'''
for case in cases:
 values=[v[(case['case_id'],p)] for p in ['signer_cold_prepare','signer_cold_total','verifier_prepare_pure','supplement_prepared_verify']]
 section+=case['witness_size']+' & '+case['participating_authorities']+' & '+' & '.join(f'{x:.3f}' for x in values)+r'\\'+'\n'
section+=r'\bottomrule\end{tabular}\end{table}'+'\n\n'
section+='At 64 attributes/64 AAs, cold preparation and cold signing take '+n('signer_cold_prepare')+' and '+n('signer_cold_total')+' ms; pure verifier preparation takes '+n('verifier_prepare_pure')+' ms.\n\n'
for stage in ['status','root']:
 section+=stage.capitalize()+' refresh at this endpoint takes '+n('refresh_'+stage+'_issuer_update')+' ms for issuer update, '+n('refresh_'+stage+'_cold_signer_prepare')+' ms for authenticated signer preparation, and '+n('refresh_'+stage+'_verifier_prepare_pure')+' ms for pure verifier preparation. '
section+='Each refresh phase has 15 measured observations per configuration; each sample restarts from the baseline rather than representing an accumulating revocation chain.\n\n'
section+='A separate instrumented signing execution measures perturbation ('+n('component_perturb')+' ms), syndrome computation ('+n('component_syndrome')+' ms), gadget sampling ('+n('component_gadget')+' ms), and trapdoor lifting/composition ('+n('component_lift')+' ms). These components exclude hashing, salt generation, and serialization, so their sum is not full online signing latency or an estimate of hardened-sampler cost. They do not attribute the endpoint trend in the separate original batch.\n\n'
amort=list(csv.DictReader((run/'amortization_sensitivity.csv').open()));a={int(x['reuse_requests']):x for x in amort if x['case_id']=='XD_K64'}
section+='Per-process reuse models use cold preparation divided by reuse count plus paired total-minus-preparation signing time, or pure verifier preparation divided by reuse count plus prepared verification. For reuse counts 1, 10, and 100, process-median signer costs are '+', '.join(f"{float(a[k]['modeled_signer_ms_per_request']):.3f}" for k in [1,10,100])+' ms/request, and verifier costs are '+', '.join(f"{float(a[k]['modeled_verifier_ms_per_request']):.3f}" for k in [1,10,100])+' ms/request. These are derived sensitivity values for unchanged valid state, not measured network workloads or guaranteed cache-hit rates; invalidation renews preparation.\n\n'
p=base/'manuscript/electronics_manuscript_revised.tex';r=base/'manuscript/response_to_reviewers.tex';b=base/'revision_work_20261008'/('before_supplement_results_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));b.mkdir()
for f in [p,r]:shutil.copy2(f,b/f.name)
s=p.read_text(encoding='utf-8');assert '\\label{sec:supplement-cold}' not in s
anchor=re.search(r'\\subsection\{[^}]*Storage[^}]*\}',s).group();s=s.replace(anchor,section+anchor,1)
s=s.replace('full signer-side cold authentication is not measured.','a separate five-process batch measures complete local cold signing at '+n('signer_cold_total')+' ms and pure verifier preparation at '+n('verifier_prepare_pure')+' ms, excluding network retrieval and disk.',1)
s=s.replace('Full signer cold authentication and network measurements remain outside the evaluation.','A separate supplemental batch adds complete local cold signer authentication and pure verifier preparation; network measurements remain outside the evaluation.',1)
s=s.replace('Neither complete cold signer authentication nor optimized pure verifier preparation has been measured.','The original batch does not measure complete cold signer authentication or pure verifier preparation; Section~\\ref{sec:supplement-cold} reports both in a separate supplemental batch.',1)
s=s.replace('missing full signer cold/network measurements','unmeasured network retrieval and trust-anchor provisioning',1)
s=s.replace('Attribution of this overhead requires component-level instrumentation.','The supplemental instrumentation characterizes a separate batch and does not attribute this original endpoint trend.',1)
p.write_text(s,encoding='utf-8')
t=r.read_text(encoding='utf-8');start=t.index('\\comment{3: Prepared-path measurements omit scaling work}');end=t.index('\\comment{4:',start)
reply=r'''\comment{3: Prepared-path measurements omit scaling work}
\response We retain the original ten-round evidence and add a separate five-process batch over the same 23 configurations, with ten measured ordinary iterations plus two warmups per process. Complete local cold signer preparation now authenticates evidence, checks public/private binding and aggregate consistency, and performs admission and sampler preparation; cold total adds fresh signing. At 64 attributes/64 AAs, cold preparation, cold signing, and pure verifier preparation take '''+n('signer_cold_prepare')+', '+n('signer_cold_total')+', and '+n('verifier_prepare_pure')+r''' ms. Pure verifier preparation builds the authenticated cache without a probe token. Status/root refresh each receive three measured iterations plus one warmup per process/configuration. Reuse sensitivity uses paired same-invocation signing residuals and per-process models. Inputs and trusted keys are memory-resident; network retrieval, disk, issuance, and trust-anchor provisioning remain unmeasured. We do not infer authority-independent complete workflow cost or cross-batch paired ratios.
\par\noindent\textbf{Revision location.} Results: Supplemental Complete Local Preparation and Sampling Components; original scaling and amortization subsections.

'''
t=t[:start]+reply+t[end:];start=t.index('\\comment{5:');end=t.index('\\comment{6:',start);chunk=t[start:end];needle='\\par\\noindent\\textbf{Revision location.}'
chunk=chunk.replace(needle,' A separate signing execution now measures perturbation, syndrome, gadget, and trapdoor-lift components. These exclude hashing, salt generation and serialization and do not estimate hardened performance.\n'+needle,1);t=t[:start]+chunk+t[end:];t=t.replace('Component-level timing and a hardened sampler are still absent, so we do not claim those optional enhancements have been completed.','Component-level research timing is now supplied by the separate supplemental batch; a hardened sampler remains outside scope.');r.write_text(t,encoding='utf-8')
(run/'supplement_manuscript_section.tex').write_text(section,encoding='utf-8');(run/'paper_sync_receipt.json').write_text(json.dumps({'status':'source updated','backup':str(b),'pdf':'pending'},indent=2),encoding='utf-8')
print('Paper source and replies synchronized.')
