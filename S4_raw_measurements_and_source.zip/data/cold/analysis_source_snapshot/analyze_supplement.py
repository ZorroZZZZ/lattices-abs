"""Validate all supplemental observations and summarize independent-process medians."""
from pathlib import Path
import csv,json,statistics,math,hashlib,random,sys
P=Path(__file__).resolve().parent
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path((P/'latest_supplement_formal_run.txt').read_text().strip())
meta=json.loads((root/'run_metadata.json').read_text(encoding='utf-8'));assert meta['status']=='PASS'
cfg=meta['configuration']['formal'];assert len(meta['rounds'])==cfg['rounds'] and all(x['exit_code']==0 for x in meta['rounds'])
cases=list(csv.DictReader((root/'source_snapshot/correctness_matrix.csv').open()))
ordinary={'signer_cold_prepare','signer_cold_total','verifier_prepare_pure','supplement_prepared_verify','component_perturb','component_syndrome','component_gadget','component_lift'}
refresh={p+s for p in ['refresh_status','refresh_root'] for s in ['_issuer_update','_cold_signer_prepare','_cold_signer_total','_verifier_prepare_pure']}
rows=[];groups={};pairs={}
for run in meta['rounds']:
    current=list(csv.DictReader((root/f"round_{run['round']:02d}"/'raw.csv').open()))
    assert len(current)==len(cases)*(len(ordinary)*(cfg['trials']+cfg['warmups'])+len(refresh)*4)
    for case in cases:
        selected=[x for x in current if x['case_id']==case['case_id']]
        for phase in ordinary|refresh:
            assert len([x for x in selected if x['phase']==phase and x['warmup']=='0'])==(cfg['trials'] if phase in ordinary else 3)
    for row in current:
        assert row['ok']=='1' and math.isfinite(float(row['ms'])) and float(row['ms'])>=0
        if row['phase'].endswith('_total') or row['phase']=='supplement_prepared_verify':assert int(row['object_bytes'])==78522
        if row['warmup']=='0':
            groups.setdefault((int(row['round']),row['case_id'],row['phase']),[]).append(float(row['ms']))
            pairs.setdefault((int(row['round']),row['case_id'],int(row['trial'])),{})[row['phase']]=float(row['ms'])
    rows+=current
for (rd,case,trial),v in pairs.items():
    for prefix in ['signer_cold','refresh_status_cold_signer','refresh_root_cold_signer']:
        if prefix+'_total' in v:
            assert v[prefix+'_total']>=v[prefix+'_prepare']
            groups.setdefault((rd,case,prefix+'_sign_residual'),[]).append(v[prefix+'_total']-v[prefix+'_prepare'])
rounds={key:statistics.median(values) for key,values in groups.items()};agg={}
for (rd,case,phase),value in rounds.items():agg.setdefault((case,phase),[]).append(value)
rng=random.Random(20261008)
summary=[]
for (case,phase),data in sorted(agg.items()):
    assert len(data)==cfg['rounds']
    boots=sorted(statistics.median(rng.choices(data,k=len(data))) for _ in range(5000))
    summary.append({'case_id':case,'phase':phase,'independent_processes':len(data),'median_of_process_medians_ms':statistics.median(data),'min_process_median_ms':min(data),'max_process_median_ms':max(data),'bootstrap95_low_ms':boots[124],'bootstrap95_high_ms':boots[4874]})
with (root/'supplement_summary.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=summary[0].keys());writer.writeheader();writer.writerows(summary)
lookup={(x['case_id'],x['phase']):x['median_of_process_medians_ms'] for x in summary}
amort=[]
for case in cases:
    cid=case['case_id']
    for n in [1,2,5,10,20,50,100,1000]:
        # Compute each process's paired model, then aggregate across processes.
        sign=[rounds[(rd,cid,'signer_cold_prepare')]/n+rounds[(rd,cid,'signer_cold_sign_residual')] for rd in range(cfg['rounds'])]
        verify=[rounds[(rd,cid,'verifier_prepare_pure')]/n+rounds[(rd,cid,'supplement_prepared_verify')] for rd in range(cfg['rounds'])]
        amort.append({'case_id':cid,'reuse_requests':n,'modeled_signer_ms_per_request':statistics.median(sign),'modeled_verifier_ms_per_request':statistics.median(verify),'interpretation':'derived, one current prepared state, no invalidation, no network'})
with (root/'amortization_sensitivity.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=amort[0].keys());writer.writeheader();writer.writerows(amort)
# Algebraic four-component shares are computed from same-trial values.
shares={}
for (rd,cid,trial),v in pairs.items():
    if 'component_perturb' in v:
        total=sum(v['component_'+x] for x in ['perturb','syndrome','gadget','lift'])
        shares.setdefault((rd,cid),[]).append((v['component_perturb']+v['component_gadget'])/total)
primary='XD_K64';primary_share=statistics.median(statistics.median(shares[(rd,primary)]) for rd in range(cfg['rounds']))
audit={'status':'PASS','raw_rows':len(rows),'measured_rows':sum(x['warmup']=='0' for x in rows),'case_count':len(cases),'distinct_witness_authority_pairs':len({(x['witness_size'],x['participating_authorities']) for x in cases}),'processes':cfg['rounds'],'ordinary_measured_per_case':cfg['rounds']*cfg['trials'],'refresh_measured_per_phase_case':cfg['rounds']*3,'all_recorded_ok':True,'token_bytes':78522,'sampler_share_of_four_components_primary':primary_share,'credential_dataset':'fixed coefficient seeds inherited from original harness; independent processes are timing replicates, not independent secret populations','ci_scope':'descriptive bootstrap over 5 process medians; limited number of independent processes','scope':'local memory-resident evidence; research sampler; total includes aggregate secret consistency check; no network/disk; not production crypto'}
(root/'supplement_validation.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
lines=['# 补充实验结果','',f"5 个独立进程、23 测试项（20 个不同的属性数/权威数对，含重复端点）。共 {len(rows)} 条原始记录，其中 {audit['measured_rows']} 条测量；所有记录通过，令牌保持 78,522 B。普通阶段每配置50次测量，刷新每类每配置15次。",'', '统计为各进程中位数的中位数。5个独立进程的置信区间仅作描述。与原10轮数据分开，不进行跨批次配对比。','', '| 配置 | 完整冷准备 ms | 完整冷签名 ms | 纯验证准备 ms | 准备后验证 ms |','|---|---:|---:|---:|---:|']
for cid in ['XD_K01','XD_K08','XD_K32','XD_K64','FW64_J01','FW64_J64']:
    vals=[lookup[(cid,p)] for p in ['signer_cold_prepare','signer_cold_total','verifier_prepare_pure','supplement_prepared_verify']];lines.append('| '+cid+' | '+' | '.join(f'{v:.3f}' for v in vals)+' |')
lines+=['','## 64属性、64权威的刷新与组件','']
for phase in sorted(ordinary|refresh):lines.append(f"- {phase}: {lookup[(primary,phase)]:.3f} ms")
lines+=['',f'扰动及 gadget 采样合计占四个被测代数组件的 {primary_share:.2%}；不是整个在线签名的占比，也不是生产采样器估计。','', '## 复用敏感性','', '| 复用次数 | 签名方每次均摊 ms | 验证方每次均摊 ms |','|---:|---:|---:|']
for x in amort:
    if x['case_id']==primary:lines.append(f"| {x['reuse_requests']} | {x['modeled_signer_ms_per_request']:.3f} | {x['modeled_verifier_ms_per_request']:.3f} |")
lines+=['','均摊为测量基础上的模型计算，不是实际网络工作负载。状态变化时重新准备；并非保证会有缓存命中。完整冷签名包含本地认证、公开/私有绑定、聚合陷门一致性检查及采样准备；输入和可信公钥已在内存，排除网络、磁盘、密钥分发及初始签发。','', '能力系数沿用原驱动的固定种子数据；独立进程重复用于计时，不是不同秘密总体的采样，也不能用零失败估算密码学拒绝概率。','', '纯验证准备直接认证证据、构建缓存，不包含探针令牌验证。冷签名输出及刷新令牌均由原完整验证器作计时外对照；DUR/root/status篡改、错误版本、重放和旧缓存均有拒绝检查。','', '所有结果只描述有限支持浮点研究采样器。过程峰值工作集不能视为独立算法内存。此次实验不解决安全归约。']
(root/'补充实验结果.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps(audit,indent=2))
