"""Run independent research rounds; pilot observations are kept separate from formal data."""
from pathlib import Path
import argparse,subprocess,json,hashlib,datetime,platform,csv,statistics,math,shutil
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['pilot','formal'],default='pilot');args=parser.parse_args()
config={'pilot':{'matrix':'pilot_matrix.csv','rounds':1,'trials':2,'warmups':1},'formal':{'matrix':'correctness_matrix.csv','rounds':5,'trials':10,'warmups':2},'refresh_measured_per_case_round':3,'refresh_warmups':1,'scope':'local memory-resident inputs, no prepared cache; research sampler; no network or disk latency'};cfg=config[args.mode]
exe=Path((P/'latest_supplement_executable.txt').read_text().strip());matrix=P/cfg['matrix']
expected=list(csv.DictReader(matrix.open()))
root=P/('supplement_'+args.mode+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir()
source=[P/x for x in ['maa_supplement.cpp','maa_profile.cpp','schema_generated.h','run_supplement.py','../revision_current/code_revision/stage13c_lattice_onlineoffline.cpp',cfg['matrix']]]+[exe]
metadata={'mode':args.mode,'configuration':config,'python':platform.python_version(),'os':platform.platform(),'machine':platform.machine(),'source_sha256':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in source},'rounds':[],'status':'RUNNING','started_local':datetime.datetime.now().isoformat()}
probe=subprocess.run(['powershell.exe','-NoProfile','-Command','Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json'],capture_output=True,text=True)
metadata['cpu']=json.loads(probe.stdout) if probe.returncode==0 else {'probe_failed':True}
shutil.copy2(exe.parent/'SOURCE_AND_BINARY_SHA256.json',root/'build_provenance.json')
snapshot=root/'source_snapshot';snapshot.mkdir()
for f in source[:-1]:shutil.copy2(f,snapshot/f.name)
def save(): (root/'run_metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
save();rows=[]
try:
    for round_id in range(cfg['rounds']):
        out=root/f'round_{round_id:02d}';out.mkdir()
        command=[str(exe),str(matrix),str(out),str(cfg['trials']),str(cfg['warmups']),str(round_id)]
        print(f'ROUND_BEGIN mode={args.mode} round={round_id} output={out}',flush=True)
        with (out/'driver.log').open('w',encoding='utf-8') as log:
            result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
        receipt={'round':round_id,'exit_code':result.returncode,'command':command,'status':'PASS' if result.returncode==0 else 'FAIL'}
        metadata['rounds'].append(receipt);save()
        if result.returncode:raise RuntimeError('Driver failed; partial data retained: '+str(out/'driver.log'))
        current=list(csv.DictReader((out/'raw.csv').open()))
        expected_phases={'signer_cold_prepare','signer_cold_total','verifier_prepare_pure','supplement_prepared_verify','component_perturb','component_syndrome','component_gadget','component_lift'}
        refresh_phases={prefix+suffix for prefix in ['refresh_status','refresh_root'] for suffix in ['_issuer_update','_cold_signer_prepare','_cold_signer_total','_verifier_prepare_pure']}
        for case in expected:
            selected=[x for x in current if x['case_id']==case['case_id']]
            for phase in expected_phases|refresh_phases:
                active=[x for x in selected if x['phase']==phase and x['warmup']=='0']
                count=3 if phase in refresh_phases else cfg['trials']
                if len(active)!=count:raise RuntimeError('Incomplete phase '+case['case_id']+' '+phase)
            for row in selected:
                if row['ok']!='1' or not math.isfinite(float(row['ms'])) or float(row['ms'])<0:raise RuntimeError('Invalid observation')
                if (row['phase'].endswith('_total') or row['phase']=='supplement_prepared_verify') and int(row['object_bytes'])!=78522:raise RuntimeError('Wrong RC1 token size')
        rows.extend(current);print(f'ROUND_PASS round={round_id} raw_rows={len(current)}',flush=True)
    groups={}
    for row in rows:
        if row['warmup']=='0':groups.setdefault((row['round'],row['case_id'],row['phase']),[]).append(row)
    with (root/'round_summary.csv').open('w',newline='') as f:
        names=['round','case_id','phase','n','median_ms','mean_ms','stdev_ms','min_ms','max_ms','median_object_bytes'];writer=csv.DictWriter(f,fieldnames=names);writer.writeheader()
        for key,group in sorted(groups.items()):
            data=[float(x['ms']) for x in group];writer.writerow(dict(zip(names,[*key,len(data),statistics.median(data),statistics.mean(data),statistics.stdev(data) if len(data)>1 else '',min(data),max(data),statistics.median(int(x['object_bytes']) for x in group)])))
    metadata.update(status='PASS',raw_rows=len(rows),completed_local=datetime.datetime.now().isoformat(),formal_collection_complete=args.mode=='formal');save()
    (P/f'latest_supplement_{args.mode}_run.txt').write_text(str(root),encoding='utf-8')
    print('SUPPLEMENT_RUN_PASS='+str(root),flush=True)
except Exception as exc:
    metadata.update(status='FAIL',error=str(exc),formal_collection_complete=False);save();raise
