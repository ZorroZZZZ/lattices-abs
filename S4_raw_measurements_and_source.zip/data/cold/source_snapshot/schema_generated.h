// Generated from pinned RC1 schema; normative metadata only.
#pragma once
static const std::map<std::string,std::vector<std::string>> MAA_SCHEMA = {
{"parameters", {"text","u32","u32","u64","u32","u32","u32","u32","u32","u32","text","text","text","text","u64"}},
{"setup-matrix", {"b32","b32","b32"}},
{"dur-registration", {"b32","b32","b32","u64","u64","u64"}},
{"credential", {"b32","b32","text","text","text","b32","u64","public-matrix","u64","u64"}},
{"leaf", {"obj:credential","b32"}},
{"merkle-node", {"b32","b32"}},
{"merkle-empty", {"b32","b32","text","u64","u64"}},
{"aa-root", {"b32","b32","text","u64","u64","b32","u64","u64"}},
{"public-root", {"b32","b32","public-matrix"}},
{"selected", {"b32","b32","text","u64","u64","u8"}},
{"selected-list", {"list:selected"}},
{"status", {"b32","b32","text","u64","u64","b32","u8","u64"}},
{"manifest", {"b32","b32","b32","u64","b32","b32","obj:selected-list","b32","u64"}},
{"request", {"text","b32","b32","text","text","policy","u64"}},
{"message", {"b32","b32","b32","payload","obj:request","b32"}},
{"token", {"b32","b32","b32","b32","proof"}},
{"signed-dur", {"obj:dur-registration","signature"}},
{"signed-credential", {"obj:credential","signature"}},
{"signed-root", {"obj:aa-root","signature"}},
{"signed-status", {"obj:status","signature"}},
{"opening", {"b32","u64","u64","hash-list"}},
};
static const std::string MAA_PARAM_HEX = "ba7d8f4c944a6d833dd0a29a5d2c250db3dff2eaff5d41608c48a27ae25e072b";
static const uint64_t MAA_NORM_LIMIT_LO = 16184860104879260000ULL;
static const uint64_t MAA_NORM_LIMIT_HI = 1ULL;

// Conservative integer threshold, certified by parameter_audit.py.
static constexpr uint64_t MAA_ADMISSIBILITY_INTEGER_FLOOR = 88764ULL;
