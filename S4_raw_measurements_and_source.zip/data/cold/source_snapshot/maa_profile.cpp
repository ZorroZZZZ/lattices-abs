// Independent C++ RC1 codec plus bridge to the unchanged research lattice arithmetic.
// Legacy byte-format helpers remain compiled for reuse of math, but are not called here.
#define main stage13c_unused_main
#include "../revision_current/code_revision/stage13c_lattice_onlineoffline.cpp"
#undef main
#include <ctime>
#include "schema_generated.h"
#pragma comment(lib,"normaliz.lib")
namespace maa {
using Bytes=std::vector<unsigned char>;
using Fields=std::vector<Bytes>;
static constexpr size_t MAX_OBJECT=4194304;
static void require(bool ok,const char*why){if(!ok)throw std::runtime_error(why);}
static Bytes str(const std::string&s){return Bytes(s.begin(),s.end());}
static std::string string(const Bytes&b){return std::string(b.begin(),b.end());}
static Bytes ui(uint64_t x,int n){Bytes b(n);for(int i=0;i<n;i++)b[i]=(unsigned char)(x>>(8*i));return b;}
static uint64_t value(const Bytes&b){require(b.size()<=8,"integer size");uint64_t x=0;for(size_t i=0;i<b.size();i++)x|=uint64_t(b[i])<<(8*i);return x;}
static Bytes hex(const std::string&s){require(s.size()%2==0,"hex length");Bytes b;for(size_t i=0;i<s.size();i+=2)b.push_back((unsigned char)std::stoul(s.substr(i,2),nullptr,16));return b;}
static Bytes repeated(unsigned char x){return Bytes(32,x);}
static Bytes read(const fs::path&p){std::ifstream f(p,std::ios::binary);require(bool(f),"open input");return Bytes(std::istreambuf_iterator<char>(f),{});}
static void write(const fs::path&p,const Bytes&b){std::ofstream f(p,std::ios::binary);require(bool(f),"open output");f.write((const char*)b.data(),b.size());require(bool(f),"write output");}
static Bytes frame(const std::string&domain,const Fields&fields){
 require(!domain.empty()&&domain.size()<=255&&fields.size()<=128,"framing limits");
 for(unsigned char x:domain)require(x<128,"ASCII domain");
 size_t size=6+domain.size();for(const auto&f:fields){require(f.size()<=MAX_OBJECT&&size<=MAX_OBJECT-8&&f.size()<=MAX_OBJECT-size-8,"object limit");size+=8+f.size();}
 Bytes b=ui(domain.size(),2);auto tag=str(domain);b.insert(b.end(),tag.begin(),tag.end());auto count=ui(fields.size(),4);b.insert(b.end(),count.begin(),count.end());
 for(const auto&f:fields){auto n=ui(f.size(),8);b.insert(b.end(),n.begin(),n.end());b.insert(b.end(),f.begin(),f.end());}return b;
}
struct Object{std::string domain;Fields f;};
static Object parse(const Bytes&b){
 require(b.size()>=6&&b.size()<=MAX_OBJECT,"object size");size_t p=0;
 auto take=[&](uint64_t n){require(n<=b.size()-p,"truncation");Bytes x(b.begin()+p,b.begin()+p+(size_t)n);p+=(size_t)n;return x;};
 auto n=value(take(2));require(n>=1&&n<=255,"domain length");auto domain=take(n);for(auto x:domain)require(x<128,"domain ASCII");
 auto count=value(take(4));require(count<=128,"field count limit");Object o{string(domain),{}};
 for(uint64_t i=0;i<count;i++){auto len=value(take(8));o.f.push_back(take(len));}require(p==b.size(),"trailing data");return o;
}
static Bytes sha(const Bytes&b){E2ESha256 h;auto d=h.hash(b);return Bytes(d.begin(),d.end());}
static bool accepted_word(uint64_t x){uint64_t remainder=((UINT64_MAX%Q)+1)%Q;uint64_t limit=UINT64_MAX-remainder+1;return remainder==0||x<limit;}
static std::vector<uint64_t> ring(const Bytes&b,size_t count){
 require(count<=16384,"ring count");Shake256Stream s;s.absorb(b.data(),b.size());s.finalize();
 // 2^64 mod q computed without overflowing a 64-bit word.
 uint64_t remainder=((UINT64_MAX%Q)+1)%Q,limit=UINT64_MAX-remainder+1;
 std::vector<uint64_t>v;v.reserve(count);while(v.size()<count){unsigned char w[8];s.squeeze(w,8);uint64_t x=0;for(int i=0;i<8;i++)x|=uint64_t(w[i])<<(8*i);if(accepted_word(x))v.push_back(x%Q);}return v;
}
static Bytes output_words(const std::vector<uint64_t>&v){Bytes b;for(auto x:v){auto w=ui(x,8);b.insert(b.end(),w.begin(),w.end());}return b;}
static void text_check(const Bytes&b){
 require(b.size()>=1&&b.size()<=256,"text length");int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,(const char*)b.data(),(int)b.size(),nullptr,0);require(n>0,"UTF8");
 std::wstring w(n,L'\0');require(MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,(const char*)b.data(),(int)b.size(),&w[0],n)==n,"UTF8 decode");
 for(wchar_t x:w)require(x>=32&&!(x>=127&&x<=159),"control text");require(IsNormalizedString(NormalizationC,w.data(),n)!=FALSE,"NFC text");
}
static Bytes normalized_text(const std::string&input){
 auto raw=str(input);require(!raw.empty()&&raw.size()<=1024,"text input limit");
 int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,input.data(),(int)input.size(),nullptr,0);require(n>0,"UTF8 sender");
 std::wstring w(n,L'\0');MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,input.data(),(int)input.size(),&w[0],n);
 int needed=NormalizeString(NormalizationC,w.data(),n,nullptr,0);require(needed>0,"NFC size");std::wstring normalized(needed,L'\0');int written=NormalizeString(NormalizationC,w.data(),n,&normalized[0],needed);require(written>0,"NFC normalize");
 int bytes=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,normalized.data(),written,nullptr,0,nullptr,nullptr);require(bytes>0,"UTF8 output");Bytes output(bytes);require(WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,normalized.data(),written,(char*)output.data(),bytes,nullptr,nullptr)==bytes,"UTF8 encoding");text_check(output);return output;
}
static std::vector<uint64_t> unpack(const Bytes&b,size_t count,int bits){
 require(bits>=1&&bits<=56&&b.size()==(count*bits+7)/8,"packing length");if(count*bits%8)require((b.back()>>(count*bits%8))==0,"padding");
 uint64_t acc=0;int used=0;size_t p=0;std::vector<uint64_t>out;uint64_t mask=bits==64?UINT64_MAX:((1ULL<<bits)-1);
 for(size_t i=0;i<count;i++){while(used<bits){acc|=uint64_t(b[p++])<<used;used+=8;}out.push_back(acc&mask);acc>>=bits;used-=bits;}return out;
}
static Bytes packed(const std::vector<uint64_t>&v,int bits){
 uint64_t acc=0;int used=0;Bytes b;for(auto x:v){require(bits==64||x<(1ULL<<bits),"coefficient range");acc|=x<<used;used+=bits;while(used>=8){b.push_back((unsigned char)acc);acc>>=8;used-=8;}}if(used)b.push_back((unsigned char)acc);return b;
}
static void proof_check(const std::vector<uint64_t>&v){
 uint64_t hi=0,lo=0;for(auto z:v){uint64_t x=(z&1)?(z+1)/2:z/2,whi=0,wlo=_umul128(x,x,&whi);uint64_t prev=lo;lo+=wlo;hi+=whi+(lo<prev);}
 require(hi<MAA_NORM_LIMIT_HI||(hi==MAA_NORM_LIMIT_HI&&lo<=MAA_NORM_LIMIT_LO),"proof norm");
}
static Fields list(const Bytes&b,const std::string&dom,size_t max){auto o=parse(b);require(o.domain==dom&&o.f.size()>=1&&o.f[0].size()==4,"list header");auto n=value(o.f[0]);require(n<=max&&n+1==o.f.size(),"list count");return Fields(o.f.begin()+1,o.f.end());}
static Bytes listing(const std::string&dom,const Fields&f){Fields fields{ui(f.size(),4)};fields.insert(fields.end(),f.begin(),f.end());return frame(dom,fields);}
static void validate(const std::string&name,const Bytes&b,int depth=0);
static void policy(const Bytes&b,int depth,std::set<Bytes>&ids){
 require(depth<=16,"policy depth");auto o=parse(b);
 if(o.domain=="MAA-v1/policy-leaf"){
  require(o.f.size()==5&&o.f[0]==ui(0,1)&&o.f[1].size()==32,"policy leaf");require(ids.insert(o.f[1]).second,"duplicate occurrence");for(int i=2;i<5;i++)text_check(o.f[i]);
 }else{require(o.domain=="MAA-v1/policy-node"&&o.f.size()==3&&(o.f[0]==ui(1,1)||o.f[0]==ui(2,1))&&o.f[1]<o.f[2],"policy node/order");policy(o.f[1],depth+1,ids);policy(o.f[2],depth+1,ids);}
 require(ids.size()<=64,"policy leaves");
}
static void kind_check(const std::string&kind,const Bytes&b,int depth){
 require(depth<=32,"object depth");
 if(kind=="b32")require(b.size()==32,"b32");
 else if(kind=="text")text_check(b);
 else if(kind=="u8"||kind=="u32"||kind=="u64")require(b.size()==size_t(std::stoi(kind.substr(1))/8),"integer width");
 else if(kind=="payload")require(b.size()<=1048576,"payload size");
 else if(kind=="signature")require(b.size()==2420,"signature length");
 else if(kind=="public-matrix"){auto v=unpack(b,114688,34);for(auto x:v)require(x<Q,"matrix residue");require(packed(v,34)==b,"matrix roundtrip");}
 else if(kind=="proof"){auto v=unpack(b,18432,34);proof_check(v);require(packed(v,34)==b,"proof roundtrip");}
 else if(kind=="policy"){std::set<Bytes>ids;policy(b,0,ids);require(!ids.empty(),"empty policy");}
 else if(kind.substr(0,4)=="obj:")validate(kind.substr(4),b,depth+1);
 else if(kind=="hash-list"){for(const auto&x:list(b,"MAA-v1/siblings",32))require(x.size()==32,"sibling length");}
 else if(kind=="list:selected"){
  auto f=list(b,"MAA-v1/selected-records",64);require(!f.empty(),"empty selection");Bytes previous;std::set<Bytes>cids;
  for(const auto&x:f){validate("selected",x,depth+1);auto rec=parse(x);require(previous.empty()||previous<rec.f[0],"selected order");previous=rec.f[0];require(cids.insert(rec.f[1]).second,"duplicate cid");require(rec.f[5]==ui(1,1),"revoked selection");}
 }else throw std::runtime_error("unknown field kind");
}
static Bytes parameters(){return frame("MAA-v1/parameters",{str("H64-research-1"),ui(64,4),ui(256,4),ui(Q,8),ui(8,4),ui(16,4),ui(56,4),ui(32,4),ui(7,4),ui(34,4),str("2.0"),str("488.3263734200445"),str("43346104.49987477"),str("5884862290.537376"),ui(1ULL<<28,8)});}
static void validate(const std::string&name,const Bytes&b,int depth){
 if(name=="policy"){kind_check("policy",b,depth);return;}
 if(name=="witness"){auto f=list(b,"MAA-v1/witness",64);require(!f.empty(),"empty witness");Bytes prev;for(const auto&x:f){require(x.size()==32&&(prev.empty()||prev<x),"witness order/duplicate");prev=x;}return;}
 auto it=MAA_SCHEMA.find(name);require(it!=MAA_SCHEMA.end(),"schema name");auto o=parse(b);require(o.domain=="MAA-v1/"+name&&o.f.size()==it->second.size(),"domain/count");
 for(size_t i=0;i<o.f.size();i++)kind_check(it->second[i],o.f[i],depth);
 if(it->second.size()>1&&it->second[0]=="b32"&&it->second[1]=="b32"){
  // Not all pairs of 32-byte fields are sid/param_id: node is left/right.
  if(name!="merkle-node"&&name!="selected"&&name!="opening")require(o.f[1]==hex(MAA_PARAM_HEX),"unknown parameter id");
 }
 if(name=="parameters")require(b==parameters(),"unknown profile");
 if(name=="dur-registration")require(value(o.f[4])!=0,"expiry");
 if(name=="credential")require(value(o.f[9])!=0,"expiry");
 if(name=="aa-root")require(value(o.f[6])<=(1ULL<<32)&&value(o.f[7])!=0,"root size/expiry");
 if(name=="manifest")require(value(o.f[8])!=0,"expiry");
 if(name=="selected")require(value(o.f[5])<=1,"status enum");
 if(name=="status")require(value(o.f[6])<=1&&value(o.f[7])!=0,"status/expiry");
 if(name=="opening"){
  uint64_t index=value(o.f[1]),count=value(o.f[2]),height=0,t=count?count-1:0;while(t){height++;t>>=1;}
  require(count>=1&&count<=(1ULL<<32)&&index<count&&list(o.f[3],"MAA-v1/siblings",32).size()==height,"opening bounds");
 }
 require(frame(o.domain,o.f)==b,"canonical roundtrip");
}
static Bytes enc(const std::string&name,const Fields&f){auto b=frame("MAA-v1/"+name,f);validate(name,b);return b;}
static std::map<std::string,Bytes> examples(){
 Bytes sid=repeated(1),param=sha(parameters()),pid=repeated(2),expiry=ui(2000000000,8),period=ui(7,8),occA=repeated(10),occB=repeated(11);
 require(param==hex(MAA_PARAM_HEX),"parameter derivation");std::map<std::string,Bytes>m;
 m["parameters"]=parameters();m["setup-matrix"]=enc("setup-matrix",{sid,param,repeated(6)});
 auto leafA=frame("MAA-v1/policy-leaf",{ui(0,1),occA,str("AA-1"),str("org"),str("role")});
 auto leafB=frame("MAA-v1/policy-leaf",{ui(0,1),occB,str("AA-2"),str("org"),str("device")});
 m["policy"]=frame("MAA-v1/policy-node",{ui(1,1),std::min(leafA,leafB),std::max(leafA,leafB)});m["witness"]=listing("MAA-v1/witness",{occA,occB});
 std::vector<uint64_t>matrix(114688);std::iota(matrix.begin(),matrix.end(),0);auto mat=packed(matrix,34);
 m["dur-registration"]=enc("dur-registration",{sid,param,pid,period,expiry,ui(2,8)});
 m["credential"]=enc("credential",{sid,param,str("AA-1"),str("org"),str("role"),pid,period,mat,ui(3,8),expiry});
 m["leaf"]=enc("leaf",{m["credential"],repeated(3)});auto cid=sha(m["leaf"]);
 m["merkle-node"]=enc("merkle-node",{repeated(8),repeated(9)});
 m["merkle-empty"]=enc("merkle-empty",{sid,param,str("AA-1"),period,ui(3,8)});
 m["aa-root"]=enc("aa-root",{sid,param,str("AA-1"),period,ui(3,8),cid,ui(1,8),expiry});
 m["public-root"]=enc("public-root",{sid,param,mat});
 m["selected"]=enc("selected",{occA,cid,str("AA-1"),ui(3,8),ui(4,8),ui(1,1)});
 m["selected-list"]=enc("selected-list",{listing("MAA-v1/selected-records",{m["selected"]})});
 m["status"]=enc("status",{sid,param,str("AA-1"),period,ui(4,8),cid,ui(1,1),expiry});
 m["manifest"]=enc("manifest",{sid,param,pid,period,sha(leafA),sha(listing("MAA-v1/witness",{occA})),m["selected-list"],sha(m["public-root"]),expiry});
 m["request"]=enc("request",{str("PDP-1"),repeated(4),repeated(5),str("/record"),str("read"),leafA,period});
 m["message"]=enc("message",{sid,param,sha(m["manifest"]),str("example"),m["request"],repeated(7)});
 std::vector<uint64_t>proof(18432);proof[0]=2;proof[1]=1;
 m["token"]=enc("token",{sid,param,sha(m["manifest"]),repeated(7),packed(proof,34)});
 for(const auto&x:std::vector<std::pair<std::string,std::string>>{{"signed-dur","dur-registration"},{"signed-credential","credential"},{"signed-root","aa-root"},{"signed-status","status"}})m[x.first]=enc(x.first,{m[x.second],Bytes(2420)});
 m["opening"]=enc("opening",{cid,ui(0,8),ui(1,8),listing("MAA-v1/siblings",{})});return m;
}
static void rejected(const std::string&name,const Bytes&b){bool no=false;try{validate(name,b);}catch(...){no=true;}require(no,"negative accepted");}
static void codec_negatives(const std::map<std::string,Bytes>&m){
 uint64_t rem=((UINT64_MAX%Q)+1)%Q,threshold=UINT64_MAX-rem+1;require(!accepted_word(threshold)&&!accepted_word(UINT64_MAX)&&accepted_word(threshold-1)&&(threshold-1)%Q==Q-1&&accepted_word(0)&&accepted_word(Q),"rejection boundary");
 require(normalized_text(std::string("e\xcc\x81"))==Bytes{0xc3,0xa9},"NFC encoder");
 std::cout<<"CPP_REJECTION_BOUNDARY=PASS CPP_NFC_SENDER=PASS\n";

 auto b=m.at("token");b.push_back(0);rejected("token",b);b=m.at("token");b.pop_back();rejected("token",b);
 auto f=parse(m.at("setup-matrix")).f;f[1]=Bytes(32);rejected("setup-matrix",frame("MAA-v1/setup-matrix",f));f.pop_back();rejected("setup-matrix",frame("MAA-v1/setup-matrix",f));
 f=parse(m.at("dur-registration")).f;f[3]=ui(7,1);rejected("dur-registration",frame("MAA-v1/dur-registration",f));
 f=parse(m.at("status")).f;f[6]=ui(2,1);rejected("status",frame("MAA-v1/status",f));
 f=parse(m.at("selected")).f;f[5]=ui(0,1);auto selected=frame("MAA-v1/selected",f);rejected("selected-list",frame("MAA-v1/selected-list",{listing("MAA-v1/selected-records",{selected})}));
 selected=m.at("selected");rejected("selected-list",frame("MAA-v1/selected-list",{listing("MAA-v1/selected-records",{selected,selected})}));
 f=parse(m.at("credential")).f;auto matrix=unpack(f[7],114688,34);matrix[0]=Q;f[7]=packed(matrix,34);rejected("credential",frame("MAA-v1/credential",f));
 f=parse(m.at("request")).f;f[0]=Bytes{0xff};rejected("request",frame("MAA-v1/request",f));f[0]=Bytes{'e',0xcc,0x81};rejected("request",frame("MAA-v1/request",f));
 f=parse(m.at("policy")).f;std::swap(f[1],f[2]);rejected("policy",frame("MAA-v1/policy-node",f));
 rejected("witness",listing("MAA-v1/witness",{repeated(10),repeated(10)}));
 f=parse(m.at("opening")).f;f[1]=ui(1,8);rejected("opening",frame("MAA-v1/opening",f));
 f=parse(m.at("token")).f;std::vector<uint64_t>proof(18432);proof[0]=2ULL*5884862290ULL;f[4]=packed(proof,34);validate("token",frame("MAA-v1/token",f));proof[0]=2ULL*5884862291ULL;f[4]=packed(proof,34);rejected("token",frame("MAA-v1/token",f));
 auto a=repeated(1),c=repeated(2),d=repeated(3);auto ab=sha(enc("merkle-node",{a,c}));auto dd=sha(enc("merkle-node",{d,d}));require(sha(enc("merkle-node",{ab,dd})).size()==32,"merkle three");
 std::cout<<"CPP_CODEC_NEGATIVES=PASS cases=15 norm_boundary=PASS\n";
}
static MLDKey real_key(){MLDKey k;Bytes seed(32);os_random(seed.data(),seed.size());require(E2E_KEYPAIR_INTERNAL(k.pk.data(),k.sk.data(),seed.data())==0,"keygen");SecureZeroMemory(seed.data(),seed.size());return k;}
static void signature_tests(const std::map<std::string,Bytes>&m,const fs::path&out){
 auto dur=real_key(),aa=real_key(),other=real_key();
 for(const auto&x:std::vector<std::pair<std::string,std::string>>{{"dur-registration","signed-dur"},{"aa-root","signed-root"},{"status","signed-status"}}){
  const auto&key=x.first=="dur-registration"?dur:aa;auto raw=m.at(x.first),sig=mld_sign(raw,key,true);require(mld_verify(raw,sig,key),"signature valid");require(!mld_verify(raw,sig,other),"wrong issuer key accepted");auto tamper=raw;tamper.back()^=1;require(!mld_verify(tamper,sig,key),"changed statement accepted");auto badsig=sig;badsig[0]^=1;require(!mld_verify(raw,badsig,key),"changed signature accepted");
  auto wrapper=enc(x.second,{raw,sig});write(out/(x.second+"-real.bin"),wrapper);write(out/(x.first+"-pk.bin"),key.pk);
  std::cout<<"REAL_MLDSA_"<<x.first<<"=PASS\n";
 }
 SecureZeroMemory(dur.sk.data(),dur.sk.size());SecureZeroMemory(aa.sk.data(),aa.sk.size());SecureZeroMemory(other.sk.data(),other.sk.size());
}
} // namespace maa
namespace maa {
static Bytes random32(){Bytes b(32);os_random(b.data(),b.size());return b;}
static Bytes matrix_bytes(const MatU&m){std::vector<uint64_t>v;v.reserve(114688);for(const auto&r:m)for(const auto&p:r)for(auto x:p)v.push_back(x);return packed(v,34);}
static MatU matrix_value(const Bytes&b){auto v=unpack(b,114688,34);MatU m(D,std::vector<PolyU>(W));size_t z=0;for(auto&r:m)for(auto&p:r)for(auto&x:p)x=v[z++];return m;}
static Bytes proof_bytes(const VecI&e){std::vector<uint64_t>v;for(const auto&p:e)for(auto x:p){uint64_t ax=x>=0?uint64_t(x):uint64_t(-(x+1))+1;require(ax<(1ULL<<33),"signed coefficient limit");v.push_back(x>=0?2*ax:2*ax-1);}proof_check(v);return packed(v,34);}
static VecI proof_value(const Bytes&b){auto v=unpack(b,18432,34);proof_check(v);VecI e(ROOT_WIDTH);size_t z=0;for(auto&p:e)for(auto&x:p){auto a=v[z++];x=(a&1)?-int64_t((a+1)/2):int64_t(a/2);}return e;}
static std::vector<PolyU> target(const Bytes&message){auto v=ring(message,D*N);std::vector<PolyU>u(D);size_t z=0;for(auto&p:u)for(auto&x:p)x=v[z++];return u;}

struct MerkleTree {
 std::vector<Fields>levels;
 explicit MerkleTree(Fields leaves){
  require(!leaves.empty()&&leaves.size()<=(1ULL<<32),"Merkle leaf count");std::sort(leaves.begin(),leaves.end());
  for(size_t i=0;i<leaves.size();i++)require(leaves[i].size()==32&&(i==0||leaves[i-1]!=leaves[i]),"Merkle duplicate leaf");levels.push_back(std::move(leaves));
  while(levels.back().size()>1){const auto&cur=levels.back();Fields next;for(size_t i=0;i<cur.size();i+=2)next.push_back(sha(enc("merkle-node",{cur[i],cur[std::min(i+1,cur.size()-1)]})));levels.push_back(std::move(next));}
 }
 Bytes root()const{return levels.back()[0];}
 Bytes opening(const Bytes&cid)const{auto it=std::lower_bound(levels[0].begin(),levels[0].end(),cid);require(it!=levels[0].end()&&*it==cid,"Merkle member");size_t index=it-levels[0].begin(),current=index;Fields siblings;
  for(size_t l=0;l+1<levels.size();l++){size_t sibling=current^1;if(sibling>=levels[l].size())sibling=current;siblings.push_back(levels[l][sibling]);current/=2;}
  return enc("opening",{cid,ui(index,8),ui(levels[0].size(),8),listing("MAA-v1/siblings",siblings)});
 }
};
static bool verify_merkle(const Bytes&raw,const Bytes&root,uint64_t authenticated_count){try{
 validate("opening",raw);auto f=parse(raw).f;uint64_t index=value(f[1]),count=value(f[2]);require(count==authenticated_count,"signed leaf count");Bytes x=f[0];
 for(const auto&sib:list(f[3],"MAA-v1/siblings",32)){if(index%2==0&&index+1>=count)require(sib==x,"odd self sibling");x=sha(enc("merkle-node",index&1?Fields{sib,x}:Fields{x,sib}));index/=2;count=(count+1)/2;}
 return x==root;
 }catch(...){return false;}}
static Bytes balanced_policy(const Fields&policies,size_t a,size_t b){require(a<b,"empty policy");if(b-a==1)return policies[a];size_t mid=a+(b-a)/2;auto left=balanced_policy(policies,a,mid),right=balanced_policy(policies,mid,b);return frame("MAA-v1/policy-node",{ui(1,1),std::min(left,right),std::max(left,right)});}
static void merkle_suite(){size_t checks=0;for(size_t count:std::vector<size_t>{1,2,3,5,64}){Fields leaves;for(size_t i=0;i<count;i++)leaves.push_back(repeated((unsigned char)(i+1)));MerkleTree t(leaves);
 for(const auto&cid:leaves){auto opening=t.opening(cid);require(verify_merkle(opening,t.root(),count),"honest Merkle opening");require(!verify_merkle(opening,t.root(),count+1),"wrong signed leaf count accepted");checks+=2;
 auto f=parse(opening).f;if(count>1){auto sib=list(f[3],"MAA-v1/siblings",32);sib[0][0]^=1;f[3]=listing("MAA-v1/siblings",sib);require(!verify_merkle(frame("MAA-v1/opening",f),t.root(),count),"bad sibling accepted");checks++;}}
 }bool rejected_duplicate=false;try{MerkleTree bad({repeated(1),repeated(1)});}catch(...){rejected_duplicate=true;}require(rejected_duplicate,"duplicate leaves accepted");std::cout<<"CPP_MULTILEAF_MERKLE=PASS checks="<<checks+1<<" sizes=1,2,3,5,64\n";
}
struct RunContext{Bytes sid,pid,seed;RunContext():sid(random32()),pid(random32()),seed(random32()){} };
static RunContext&run_context(){static RunContext r;return r;}
static std::map<int,Bytes> partition_roots;
// For every unit-modulus r: ||T(r)||_2 <= ||T(r)||_F <= sqrt(N * sum_t ||T_t||_F^2).
// Accumulation stops at a small exact budget; division guards multiplication against overflow.
static bool coefficient_budget_add(uint64_t&sum,i64 coefficient,uint64_t limit){
 uint64_t magnitude=coefficient<0?uint64_t(-(coefficient+1))+1:uint64_t(coefficient);
 if(sum>limit)return false;auto remaining=limit-sum;if(magnitude&&magnitude>remaining/magnitude)return false;sum+=magnitude*magnitude;return true;
}
static bool exact_trapdoor_gate(const MatI&T,uint64_t*sum_out=nullptr){
 constexpr uint64_t b=MAA_ADMISSIBILITY_INTEGER_FLOOR,limit=(b*b-1)/N;
 if(T.size()!=M0)return false;uint64_t sum=0;for(const auto&row:T){if(row.size()!=W)return false;for(const auto&poly:row)for(auto x:poly)if(!coefficient_budget_add(sum,x,limit))return false;}
 if(sum_out)*sum_out=sum;return true;
}
static void exact_gate_suite(){uint64_t sum=0;require(coefficient_budget_add(sum,3,25)&&coefficient_budget_add(sum,-4,25)&&sum==25,"exact gate equality");require(!coefficient_budget_add(sum,1,25)&&sum==25,"exact gate excess");sum=0;require(!coefficient_budget_add(sum,std::numeric_limits<i64>::min(),25)&&sum==0,"exact gate INT64_MIN");require(!coefficient_budget_add(sum,std::numeric_limits<i64>::max(),25),"exact gate INT64_MAX");MatI bad;require(!exact_trapdoor_gate(bad),"exact gate shape");MatI zero(M0,std::vector<PolyI>(W));require(exact_trapdoor_gate(zero),"exact gate zero");std::cout<<"CPP_EXACT_ADMISSIBILITY_GATE=PASS cases=6 ld_digits="<<std::numeric_limits<ld>::digits<<" ld_bytes="<<sizeof(ld)<<std::endl;}
static void reserve_preparation(){require(preparation_counter<Q_PREP_MAX,"preparation budget");++preparation_counter;}
static void budget_suite(){auto old=preparation_counter;preparation_counter=Q_PREP_MAX;bool rejected=false;try{reserve_preparation();}catch(...){rejected=true;}require(rejected&&preparation_counter==Q_PREP_MAX,"exhausted budget accepted");preparation_counter=Q_PREP_MAX-1;reserve_preparation();require(preparation_counter==Q_PREP_MAX,"budget last slot");preparation_counter=old;std::cout<<"CPP_PREPARATION_BUDGET_BOUNDARY=PASS\n";}
struct Presented {Bytes occurrence,credential,leaf,root,root_sig,status,status_sig,opening;int authority=0;MLDKey issuer_key;};
struct SmokeState {Bytes sid,param,pid,setup,dur,dur_sig,policy,witness,manifest,request,payload;MLDKey dur_key;std::vector<Presented>presented;uint64_t period=7,root_version=3,status_version=4;std::set<Bytes>consumed;};

static void authenticate_issuer_trees(SmokeState&s,size_t minimum_leaves){
 std::map<int,std::vector<size_t>>groups;for(size_t i=0;i<s.presented.size();i++)groups[s.presented[i].authority].push_back(i);
 for(const auto&group:groups){Fields leaves;for(auto ix:group.second)leaves.push_back(sha(s.presented[ix].leaf));while(leaves.size()<minimum_leaves)leaves.push_back(sha(random32()));MerkleTree tree(leaves);
  auto&first=s.presented[group.second.front()];auto cr=parse(first.credential).f;auto root=enc("aa-root",{s.sid,s.param,cr[2],ui(s.period,8),ui(s.root_version,8),tree.root(),ui(leaves.size(),8),cr[9]});auto root_sig=mld_sign(root,first.issuer_key,true);
  for(auto ix:group.second){auto&rec=s.presented[ix];auto credential=parse(rec.credential).f;auto cid=sha(rec.leaf);rec.root=root;rec.root_sig=root_sig;rec.opening=tree.opening(cid);
   rec.status=enc("status",{s.sid,s.param,credential[2],ui(s.period,8),ui(s.status_version,8),cid,ui(1,1),credential[9]});rec.status_sig=mld_sign(rec.status,rec.issuer_key,true);}
 }
}
static Bytes make_manifest(const SmokeState&s,const Bytes&public_digest,const Bytes&expiry){Fields records;for(const auto&rec:s.presented){auto cid=sha(rec.leaf),cr=parse(rec.credential).f[2];records.push_back(enc("selected",{rec.occurrence,cid,cr,ui(s.root_version,8),ui(s.status_version,8),ui(1,1)}));}
 std::sort(records.begin(),records.end(),[](const Bytes&a,const Bytes&b){return parse(a).f[0]<parse(b).f[0];});auto selection=enc("selected-list",{listing("MAA-v1/selected-records",records)});
 return enc("manifest",{s.sid,s.param,s.pid,ui(s.period,8),sha(s.policy),sha(s.witness),selection,public_digest,expiry});
}
static uint64_t unique_size(const Fields&objects){std::set<Bytes>unique(objects.begin(),objects.end());uint64_t total=0;for(const auto&b:unique)total+=b.size();return total;}
static uint64_t cold_support_bytes(const SmokeState&s){Fields objects{s.manifest,s.witness,s.setup,enc("signed-dur",{s.dur,s.dur_sig}),s.dur_key.pk};for(const auto&rec:s.presented){objects.push_back(rec.leaf);objects.push_back(rec.opening);objects.push_back(enc("signed-root",{rec.root,rec.root_sig}));objects.push_back(enc("signed-status",{rec.status,rec.status_sig}));objects.push_back(rec.issuer_key.pk);}return unique_size(objects);}
static RootInst public_root(const MatU&Ahat,const std::vector<Presented>&records){
 RootInst r;r.Ahat=Ahat;r.Bpub=MatU(D,std::vector<PolyU>(W));
 for(const auto&rec:records){auto f=parse(rec.credential).f;auto B=matrix_value(f[7]);for(int i=0;i<D;i++)for(int j=0;j<W;j++)for(int t=0;t<N;t++)r.Bpub[i][j][t]=add_mod(r.Bpub[i][j][t],B[i][j][t]);}
 for(int i=0;i<D;i++)for(int j=0;j<KG;j++)for(size_t t=1;t<records.size();t++)r.Bpub[i][i*KG+j][0]=sub_mod(r.Bpub[i][i*KG+j][0],pow_mod(RADIX,j));return r;
}
static bool witness_ok(const Bytes&raw,const std::set<Bytes>&selected,std::set<Bytes>&got){
 auto o=parse(raw);if(o.domain=="MAA-v1/policy-leaf"){if(!selected.count(o.f[1]))return false;got.insert(o.f[1]);return true;}
 std::set<Bytes>a,b;bool av=witness_ok(o.f[1],selected,a),bv=witness_ok(o.f[2],selected,b);
 if(value(o.f[0])==1){if(!av||!bv)return false;got=a;got.insert(b.begin(),b.end());return true;}
 if(av==bv)return false;got=av?a:b;return true;
}
static void policy_records(const Bytes&raw,std::map<Bytes,Fields>&leaves){auto o=parse(raw);if(o.domain=="MAA-v1/policy-leaf")leaves[o.f[1]]=o.f;else{policy_records(o.f[1],leaves);policy_records(o.f[2],leaves);}}
static bool smoke_verify(SmokeState&s,const Bytes&token,const Bytes&request,const Bytes&payload,uint64_t now){
 try{
  validate("token",token);validate("manifest",s.manifest);validate("request",request);validate("dur-registration",s.dur);validate("setup-matrix",s.setup);
  auto tk=parse(token).f,man=parse(s.manifest).f,req=parse(request).f,dur=parse(s.dur).f,setup=parse(s.setup).f;
  require(request==s.request,"not issued request");require(!s.consumed.count(req[1]),"nonce replay");
  require(tk[0]==s.sid&&tk[1]==s.param&&tk[2]==sha(s.manifest),"token context");
  require(man[0]==s.sid&&man[1]==s.param&&man[2]==s.pid&&value(man[3])==s.period&&value(man[8])>now,"manifest context/expiry");
  require(setup[0]==s.sid&&setup[1]==s.param,"setup context");
  require(mld_verify(s.dur,s.dur_sig,s.dur_key),"DUR authentication");require(dur[0]==s.sid&&dur[1]==s.param&&dur[2]==s.pid&&value(dur[3])==s.period&&value(dur[4])>=value(man[8])&&value(dur[4])>now,"DUR binding/expiry");
  require(value(req[6])==s.period&&sha(req[5])==man[4]&&req[5]==s.policy,"request policy/period");
  validate("witness",s.witness);auto ids=list(s.witness,"MAA-v1/witness",64);require(sha(s.witness)==man[5],"witness digest");std::set<Bytes>selected(ids.begin(),ids.end()),got;require(witness_ok(s.policy,selected,got)&&got==selected,"witness satisfaction");
  auto selected_obj=parse(man[6]);auto records=list(selected_obj.f[0],"MAA-v1/selected-records",64);require(records.size()==s.presented.size()&&records.size()==selected.size(),"record count");
  std::map<Bytes,Fields>leaves;policy_records(s.policy,leaves);std::map<Bytes,Fields>selections;for(const auto&x:records){auto f=parse(x).f;require(selected.count(f[0])&&selections.emplace(f[0],f).second,"selected witness");}
  for(const auto&rec:s.presented){
   validate("leaf",rec.leaf);validate("aa-root",rec.root);validate("status",rec.status);auto cr=parse(rec.credential).f,ro=parse(rec.root).f,st=parse(rec.status).f,lf=parse(rec.leaf).f;
   require(lf[0]==rec.credential,"leaf credential");auto cid=sha(rec.leaf);require(selections.count(rec.occurrence)&&leaves.count(rec.occurrence),"occurrence binding");auto sr=selections.at(rec.occurrence),pl=leaves.at(rec.occurrence);
   require(sr[1]==cid&&sr[2]==cr[2]&&sr[3]==ui(s.root_version,8)&&sr[4]==ui(s.status_version,8)&&sr[5]==ui(1,1),"selected snapshot");
   require(cr[0]==s.sid&&cr[1]==s.param&&cr[5]==s.pid&&cr[6]==ui(s.period,8)&&cr[8]==ui(s.root_version,8)&&value(cr[9])>=value(man[8])&&value(cr[9])>now,"credential context/expiry");
   require(cr[2]==pl[2]&&cr[3]==pl[3]&&cr[4]==pl[4],"attribute/issuer binding");
   require(mld_verify(rec.root,rec.root_sig,rec.issuer_key)&&mld_verify(rec.status,rec.status_sig,rec.issuer_key),"issuer authentication");
   require(ro[0]==s.sid&&ro[1]==s.param&&ro[2]==cr[2]&&ro[3]==ui(s.period,8)&&ro[4]==ui(s.root_version,8)&&verify_merkle(rec.opening,ro[5],value(ro[6]))&&parse(rec.opening).f[0]==cid&&value(ro[7])>=value(man[8])&&value(ro[7])>now,"Merkle root/opening binding");
   require(st[0]==s.sid&&st[1]==s.param&&st[2]==cr[2]&&st[3]==ui(s.period,8)&&st[4]==ui(s.status_version,8)&&st[5]==cid&&st[6]==ui(1,1)&&value(st[7])>=value(man[8])&&value(st[7])>now,"status binding");
  }
  auto coeff=ring(s.setup,D*D*N);MatU A(D,std::vector<PolyU>(D));size_t z=0;for(auto&r:A)for(auto&p:r)for(auto&x:p)x=coeff[z++];
  auto pub=public_root(A,s.presented);require(sha(enc("public-root",{s.sid,s.param,matrix_bytes(pub.Bpub)}))==man[7],"public root digest");
  auto msg=enc("message",{s.sid,s.param,tk[2],payload,request,tk[3]});auto e=proof_value(tk[4]);require(M_times_vec(pub,e)==target(msg),"lattice relation");
  s.consumed.insert(req[1]);return true;
 }catch(const std::exception&){return false;}
}
static void (*benchmark_hook)(SmokeState&,const MatU&,const std::vector<Credential>&,const RootInst&,const EvalTW&,const Schur&,std::mt19937_64&)=nullptr;
static void lattice_smoke(int k,const fs::path&out,int authorities=0,size_t minimum_leaves=0,bool or_policy=false,bool negative_checks=true,bool refresh=false){
 require(k>=1&&k<=64,"witness size");if(authorities==0)authorities=k;require(authorities>=1&&authorities<=k,"authority count");require(!or_policy||k<64,"OR leaf cap");fs::create_directories(out);
 static bool initialized=false;if(!initialized){init_ntt();init_small_leaf_table();init_gm();init_crt();initialized=true;}std::mt19937_64 rng(0xAA010000ULL+k);
 SmokeState s;s.sid=run_context().sid;s.param=hex(MAA_PARAM_HEX);s.pid=run_context().pid;s.dur_key=real_key();auto expiry=ui(uint64_t(std::time(nullptr))+3600,8);
 s.setup=enc("setup-matrix",{s.sid,s.param,run_context().seed});auto coeff=ring(s.setup,D*D*N);MatU A(D,std::vector<PolyU>(D));size_t z=0;for(auto&r:A)for(auto&p:r)for(auto&x:p)x=coeff[z++];
 s.dur=enc("dur-registration",{s.sid,s.param,s.pid,ui(s.period,8),expiry,ui(2,8)});s.dur_sig=mld_sign(s.dur,s.dur_key,true);
 std::vector<Credential>capabilities;Fields policies,records,ids;std::vector<MLDKey>issuer_keys;for(int a=0;a<authorities;a++)issuer_keys.push_back(real_key());
 for(int i=0;i<k;i++){
  Presented rec;rec.occurrence=repeated((unsigned char)(10+i));rec.authority=i%authorities;rec.issuer_key=issuer_keys[rec.authority];auto issuer=str("AA-"+std::to_string(rec.authority+1)),attr=str("attribute-"+std::to_string(i+1));
  auto cap=issue_credential(rng,A);rec.credential=enc("credential",{s.sid,s.param,issuer,str("org"),attr,s.pid,ui(s.period,8),matrix_bytes(cap.Bpub),ui(s.root_version,8),expiry});
  rec.leaf=enc("leaf",{rec.credential,random32()});auto cid=sha(rec.leaf);
  rec.root=enc("aa-root",{s.sid,s.param,issuer,ui(s.period,8),ui(s.root_version,8),cid,ui(1,8),expiry});rec.root_sig=mld_sign(rec.root,rec.issuer_key,true);
  rec.status=enc("status",{s.sid,s.param,issuer,ui(s.period,8),ui(s.status_version,8),cid,ui(1,1),expiry});rec.status_sig=mld_sign(rec.status,rec.issuer_key,true);
  records.push_back(enc("selected",{rec.occurrence,cid,issuer,ui(s.root_version,8),ui(s.status_version,8),ui(1,1)}));ids.push_back(rec.occurrence);
  policies.push_back(frame("MAA-v1/policy-leaf",{ui(0,1),rec.occurrence,issuer,str("org"),attr}));capabilities.push_back(std::move(cap));s.presented.push_back(std::move(rec));
 }
 authenticate_issuer_trees(s,minimum_leaves);
 s.policy=balanced_policy(policies,0,policies.size());if(or_policy){auto unselected=frame("MAA-v1/policy-leaf",{ui(0,1),repeated(250),str("AA-unused"),str("org"),str("unselected")});s.policy=frame("MAA-v1/policy-node",{ui(2,1),std::min(s.policy,unselected),std::max(s.policy,unselected)});}
 validate("policy",s.policy);std::sort(ids.begin(),ids.end());s.witness=listing("MAA-v1/witness",ids);
 std::sort(records.begin(),records.end(),[](const Bytes&a,const Bytes&b){return parse(a).f[0]<parse(b).f[0];});auto sel=enc("selected-list",{listing("MAA-v1/selected-records",records)});
 auto preparations_before=preparation_counter;reserve_preparation();auto root=aggregate_credentials(A,capabilities,k);uint64_t coefficient_square_sum=0;require(exact_trapdoor_gate(root.T,&coefficient_square_sum),"exact coefficient admissibility");require(verify_root_identity(root),"trapdoor identity");auto te=transform_T(root.T);ld bound=0;require(aggregate_trapdoor_admissible(te,&bound,admissibility_threshold()),"admissibility");auto schur=build_schur(te);
 auto public_digest=sha(enc("public-root",{s.sid,s.param,matrix_bytes(root.Bpub)}));if(partition_roots.count(k))require(partition_roots.at(k)==public_digest,"partition changed aggregate root");else partition_roots[k]=public_digest;s.manifest=enc("manifest",{s.sid,s.param,s.pid,ui(s.period,8),sha(s.policy),sha(s.witness),sel,public_digest,expiry});auto wid=sha(s.manifest);
 s.request=enc("request",{str("PDP-1"),random32(),random32(),str("/record"),str("read"),s.policy,ui(s.period,8)});s.payload=str("MAA-v1 lattice smoke request");auto salt=random32();auto message=enc("message",{s.sid,s.param,wid,s.payload,s.request,salt});DZ dz(rng);
 auto proof=samplepre_on_target13(root,te,schur,target(message),dz);require(proof.bench.gsample&&proof.bench.trap&&proof.bench.preimage&&proof.bench.normpass,"sampler algebra/norm");auto token=enc("token",{s.sid,s.param,wid,salt,proof_bytes(proof.e)});auto now=uint64_t(std::time(nullptr));
 require(smoke_verify(s,token,s.request,s.payload,now),"honest transcript");if(negative_checks){require(!smoke_verify(s,token,s.request,s.payload,now),"replay accepted");s.consumed.clear();
 auto bad=parse(token).f;bad[0][0]^=1;require(!smoke_verify(s,frame("MAA-v1/token",bad),s.request,s.payload,now),"cross system accepted");
 bad=parse(token).f;bad[1][0]^=1;require(!smoke_verify(s,frame("MAA-v1/token",bad),s.request,s.payload,now),"cross profile accepted");
 bad=parse(token).f;bad[2][0]^=1;require(!smoke_verify(s,frame("MAA-v1/token",bad),s.request,s.payload,now),"wrong manifest accepted");
 bad=parse(token).f;bad[3][0]^=1;require(!smoke_verify(s,frame("MAA-v1/token",bad),s.request,s.payload,now),"salt tamper accepted");
 bad=parse(token).f;bad[4][0]^=1;require(!smoke_verify(s,frame("MAA-v1/token",bad),s.request,s.payload,now),"proof tamper accepted");
 require(!smoke_verify(s,token,s.request,str("changed payload"),now),"payload tamper accepted");
 auto badreq=parse(s.request).f;badreq[1][0]^=1;require(!smoke_verify(s,token,frame("MAA-v1/request",badreq),s.payload,now),"wrong challenge accepted");
 badreq=parse(s.request).f;badreq[6]=ui(s.period+1,8);require(!smoke_verify(s,token,frame("MAA-v1/request",badreq),s.payload,now),"cross period accepted");
 require(!smoke_verify(s,token,s.request,s.payload,value(expiry)+1),"expired state accepted");
 s.root_version++;require(!smoke_verify(s,token,s.request,s.payload,now),"stale root accepted");s.root_version--;
 s.status_version++;require(!smoke_verify(s,token,s.request,s.payload,now),"stale status accepted");s.status_version--;
 s.dur_sig[0]^=1;require(!smoke_verify(s,token,s.request,s.payload,now),"DUR tamper accepted");s.dur_sig[0]^=1;
 s.presented[0].root_sig[0]^=1;require(!smoke_verify(s,token,s.request,s.payload,now),"root signature tamper accepted");s.presented[0].root_sig[0]^=1;
 s.presented[0].status_sig[0]^=1;require(!smoke_verify(s,token,s.request,s.payload,now),"status signature tamper accepted");s.presented[0].status_sig[0]^=1;
 auto original_pid=s.pid;s.pid=random32();require(!smoke_verify(s,token,s.request,s.payload,now),"cross user accepted");s.pid=original_pid;
 require(smoke_verify(s,token,s.request,s.payload,now),"restored transcript");
 }


 if(or_policy){std::set<Bytes> chosen(ids.begin(),ids.end()),got;chosen.insert(repeated(250));require(!witness_ok(s.policy,chosen,got),"both OR branches accepted");chosen.clear();require(!witness_ok(s.policy,chosen,got),"empty OR accepted");}
 const auto initial_cold=cold_support_bytes(s);std::ofstream receipts(out/"refresh_receipts.csv");receipts<<"stage,old_wid,new_wid,old_token_rejected,new_token_accepted,cold_support_bytes\n";
 if(refresh)for(int stage=0;stage<2;stage++){
  auto oldtoken=token,oldwid=wid;s.consumed.clear();
  if(stage==0){s.status_version++;for(auto&rec:s.presented){auto f=parse(rec.status).f;f[4]=ui(s.status_version,8);rec.status=enc("status",f);rec.status_sig=mld_sign(rec.status,rec.issuer_key,true);}}
  else{s.root_version++;for(auto&rec:s.presented){auto f=parse(rec.credential).f;f[8]=ui(s.root_version,8);rec.credential=enc("credential",f);rec.leaf=enc("leaf",{rec.credential,random32()});}authenticate_issuer_trees(s,minimum_leaves);}
  s.manifest=make_manifest(s,public_digest,expiry);wid=sha(s.manifest);require(wid!=oldwid,"refresh unchanged manifest");require(!smoke_verify(s,oldtoken,s.request,s.payload,now),"old token accepted after refresh");
  reserve_preparation();require(exact_trapdoor_gate(root.T),"refreshed exact admissibility");auto refreshed_te=transform_T(root.T);ld refreshed_bound=0;require(aggregate_trapdoor_admissible(refreshed_te,&refreshed_bound,admissibility_threshold()),"refreshed floating admissibility");auto refreshed_schur=build_schur(refreshed_te);
  s.request=enc("request",{str("PDP-1"),random32(),random32(),str("/record"),str("read"),s.policy,ui(s.period,8)});salt=random32();message=enc("message",{s.sid,s.param,wid,s.payload,s.request,salt});
  auto refreshed_proof=samplepre_on_target13(root,refreshed_te,refreshed_schur,target(message),dz);require(refreshed_proof.bench.gsample&&refreshed_proof.bench.trap&&refreshed_proof.bench.preimage&&refreshed_proof.bench.normpass,"refresh sampler");token=enc("token",{s.sid,s.param,wid,salt,proof_bytes(refreshed_proof.e)});require(smoke_verify(s,token,s.request,s.payload,now),"refreshed transcript");
  auto stagepath=out/(stage==0?"refresh_status":"refresh_root");fs::create_directories(stagepath);write(stagepath/"manifest.bin",s.manifest);write(stagepath/"old-token.bin",oldtoken);write(stagepath/"token.bin",token);write(stagepath/"request.bin",s.request);
  receipts<<(stage==0?"status":"root")<<",";for(auto x:oldwid)receipts<<std::hex<<std::setw(2)<<std::setfill('0')<<int(x);receipts<<",";for(auto x:wid)receipts<<std::hex<<std::setw(2)<<std::setfill('0')<<int(x);receipts<<std::dec<<",1,1,"<<cold_support_bytes(s)<<"\n";
 }
 std::ofstream summary(out/"case_summary.csv");summary<<"witness_size,participating_authorities,or_policy,initial_cold_support_bytes,final_cold_support_bytes,token_bytes,request_bytes,payload_bytes,refresh_stages,coefficient_square_sum,preparations_consumed\n"<<k<<","<<authorities<<","<<or_policy<<","<<initial_cold<<","<<cold_support_bytes(s)<<","<<token.size()<<","<<s.request.size()<<","<<s.payload.size()<<","<<(refresh?2:0)<<","<<coefficient_square_sum<<","<<(preparation_counter-preparations_before)<<"\n";require(preparation_counter-preparations_before==uint64_t(refresh?3:1),"preparation accounting");
 if(benchmark_hook)benchmark_hook(s,A,capabilities,root,te,schur,rng);
 write(out/"setup-matrix.bin",s.setup);write(out/"dur-registration.bin",s.dur);write(out/"signed-dur.bin",enc("signed-dur",{s.dur,s.dur_sig}));write(out/"manifest.bin",s.manifest);write(out/"request.bin",s.request);write(out/"message.bin",message);write(out/"token.bin",token);write(out/"policy.bin",s.policy);write(out/"witness.bin",s.witness);write(out/"public-root.bin",enc("public-root",{s.sid,s.param,matrix_bytes(root.Bpub)}));
 for(int i=0;i<k;i++){auto dir=out/("issuer_"+std::to_string(i+1));fs::create_directories(dir);auto&rec=s.presented[i];write(dir/"opening.bin",rec.opening);write(dir/"credential.bin",rec.credential);write(dir/"leaf.bin",rec.leaf);write(dir/"signed-root.bin",enc("signed-root",{rec.root,rec.root_sig}));write(dir/"signed-status.bin",enc("signed-status",{rec.status,rec.status_sig}));SecureZeroMemory(rec.issuer_key.sk.data(),rec.issuer_key.sk.size());}
 SecureZeroMemory(s.dur_key.sk.data(),s.dur_key.sk.size());
 std::cout<<"LATTICE_MAA_V1_K"<<k<<"_P"<<authorities<<"=PASS bytes="<<token.size()<<" context_negative_checks="<<(negative_checks?16:0)<<" research_sampler_only=1\n";
}
} // namespace maa

#ifndef MAA_CODEC_NO_MAIN
int main(int argc,char**argv){
 try{
  maa::require(argc==3||argc==4,"usage: maa_profile reference_vectors output_directory [matrix_csv]");fs::path vectors=argv[1],out=argv[2];fs::create_directories(out);auto m=maa::examples();
  for(const auto&x:m){auto expected=maa::read(vectors/(x.first+".bin"));maa::require(x.second==expected,"Python/C++ bytes differ");maa::validate(x.first,x.second);maa::write(out/(x.first+".bin"),x.second);if(x.first=="message"||x.first=="setup-matrix")maa::write(out/(x.first+"-ring.bin"),maa::output_words(maa::ring(x.second,x.first=="message"?2048:16384)));std::cout<<"CPP_VECTOR_"<<x.first<<"=PASS bytes="<<x.second.size()<<"\n";}
  maa::merkle_suite();maa::exact_gate_suite();maa::budget_suite();maa::codec_negatives(m);maa::signature_tests(m,out);maa::lattice_smoke(1,out/"smoke_k1");maa::lattice_smoke(2,out/"smoke_k2");maa::lattice_smoke(2,out/"smoke_multileaf_or",1,3,true,true,true);
  if(argc==4){std::ifstream cases(argv[3]);maa::require(bool(cases),"matrix CSV missing");std::string line;std::getline(cases,line);int count=0;while(std::getline(cases,line)){if(line.empty())continue;std::replace(line.begin(),line.end(),',',' ');std::istringstream row(line);std::string id;int k,p;size_t leaves;maa::require(bool(row>>id>>k>>p>>leaves),"matrix row");std::cout<<"MATRIX_BEGIN="<<id<<std::endl;maa::lattice_smoke(k,out/("case_"+id),p,leaves,false,false,false);count++;}maa::require(count==23,"matrix case count");std::cout<<"CORRECTNESS_MATRIX=PASS cases="<<count<<std::endl;}
  std::cout<<"MAA_V1_CPP_OVERALL=PASS\n";return 0;
 }catch(const std::exception&e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 20;}
}

#endif // MAA_CODEC_NO_MAIN
