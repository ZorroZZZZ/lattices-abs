// Research timing driver. Algebraic checks are outside measured signing intervals.
#define MAA_CODEC_NO_MAIN
#include "maa_profile.cpp"
namespace bench {
using namespace maa;
using Clock=std::chrono::steady_clock;
static int trials=3,warmups=1,round_id=0;
static std::string case_id;
static fs::path case_dir;
static Fields cached_cids;
static std::ofstream raw;
static double elapsed(Clock::time_point t){return std::chrono::duration<double,std::milli>(Clock::now()-t).count();}
static void record(int trial,const char*phase,double ms,uint64_t bytes,bool ok){raw<<round_id<<","<<case_id<<","<<trial<<","<<(trial<0)<<","<<phase<<","<<std::setprecision(12)<<ms<<","<<bytes<<","<<peak_rss_bytes()<<","<<ok<<"\n";raw.flush();require(ok,"benchmark operation failed");}
static Fields support(const SmokeState&s){Fields v{s.manifest,s.witness,s.setup,enc("signed-dur",{s.dur,s.dur_sig}),s.dur_key.pk};for(const auto&r:s.presented){v.push_back(r.leaf);v.push_back(r.opening);v.push_back(enc("signed-root",{r.root,r.root_sig}));v.push_back(enc("signed-status",{r.status,r.status_sig}));v.push_back(r.issuer_key.pk);}return v;}
static uint64_t changed_bytes(const Fields&before,const Fields&after){std::set<Bytes>old(before.begin(),before.end()),fresh(after.begin(),after.end());uint64_t n=0;for(const auto&b:fresh)if(!old.count(b))n+=b.size();return n;}
struct Prepared {RootInst root;Bytes wid,sid,param,pid,policy;uint64_t period,root_version,status_version,expiry;std::set<Bytes>consumed;};
static Prepared cache(SmokeState&s,const MatU&A,const Bytes&probe){auto request=parse(s.request).f;s.consumed.erase(request[1]);require(smoke_verify(s,probe,s.request,s.payload,uint64_t(std::time(nullptr))),"cache authentication probe");return {public_root(A,s.presented),sha(s.manifest),s.sid,s.param,s.pid,s.policy,s.period,s.root_version,s.status_version,value(parse(s.manifest).f[8]),{}};}
static bool prepared_verify(const SmokeState&s,Prepared&v,const Bytes&token){try{validate("token",token);validate("request",s.request);auto t=parse(token).f,r=parse(s.request).f;require(s.sid==v.sid&&s.param==v.param&&s.pid==v.pid&&s.period==v.period&&s.root_version==v.root_version&&s.status_version==v.status_version&&sha(s.manifest)==v.wid,"cache currentness");require(t[0]==v.sid&&t[1]==v.param&&t[2]==v.wid&&value(r[6])==v.period&&r[5]==v.policy&&v.expiry>uint64_t(std::time(nullptr)),"prepared context");require(!v.consumed.count(r[1]),"prepared replay");auto msg=enc("message",{v.sid,v.param,v.wid,s.payload,s.request,t[3]});require(M_times_vec(v.root,proof_value(t[4]))==target(msg),"prepared relation");v.consumed.insert(r[1]);return true;}catch(...){return false;}}
static Bytes request(const SmokeState&s){return enc("request",{str("PDP-1"),random32(),random32(),str("/record"),str("read"),s.policy,ui(s.period,8)});}
static Bytes sign(SmokeState&s,const RootInst&root,const EvalTW&te,const Schur&schur,DZ&dz,VecI&proof){
 auto salt=random32();auto msg=enc("message",{s.sid,s.param,sha(s.manifest),s.payload,s.request,salt});auto u=target(msg);RecStats stats;
 auto p=sample_perturb(dz,te,schur,stats);auto mp=M_times_vec(root,p);std::vector<PolyU>v(D);for(int i=0;i<D;i++)for(int j=0;j<N;j++)v[i][j]=sub_mod(u[i][j],mp[i][j]);
 auto z=module_gsample(dz,v);auto tz=T_times_z_exact(root.T,z);proof=VecI(ROOT_WIDTH);
 for(int i=0;i<M0;i++)for(int j=0;j<N;j++)proof[i][j]=p[i][j]+tz[i][j];for(int i=0;i<W;i++)for(int j=0;j<N;j++)proof[M0+i][j]=p[M0+i][j]+z[i][j];
 return enc("token",{s.sid,s.param,sha(s.manifest),salt,proof_bytes(proof)});
}
static void reprepare(SmokeState&s,const MatU&A,const std::vector<Credential>&caps,int trial,const char*phase){auto start=Clock::now();reserve_preparation();auto root=aggregate_credentials(A,caps,int(caps.size()));require(exact_trapdoor_gate(root.T),"prepare exact gate");auto te=transform_T(root.T);require(aggregate_trapdoor_admissible(te,nullptr,admissibility_threshold()),"prepare floating gate");auto schur=build_schur(te);auto digest=sha(enc("public-root",{s.sid,s.param,matrix_bytes(root.Bpub)}));auto manifest=make_manifest(s,digest,parse(s.manifest).f[8]);auto ms=elapsed(start);require(manifest==s.manifest&&verify_root_identity(root),"reprepare state");record(trial,phase,ms,0,true);}
static Bytes baseline_context(const SmokeState&s){return sha(frame("MAA-bench/context",{s.sid,s.param,s.pid,sha(s.policy),sha(s.witness),s.request,s.payload}));}
static void baseline(SmokeState&s,const std::vector<MLDKey>&keys,int trial,bool periodic){
 auto start=Clock::now();auto context=baseline_context(s);Fields sigs;size_t count=periodic?1:keys.size();
 for(size_t i=0;i<count;i++){auto msg=periodic?frame("MAA-bench/periodic",{context}):frame("MAA-bench/attribute",{context,s.presented[i].occurrence,cached_cids[i]});sigs.push_back(mld_sign(msg,keys[i],true));}
 auto token=frame(periodic?"MAA-bench/periodic-token":"MAA-bench/per-attribute-token",{context,listing("MAA-bench/signatures",sigs)});record(trial,periodic?"mldsa_periodic_sign":"mldsa_attribute_sign",elapsed(start),token.size(),true);
 start=Clock::now();auto parsed=parse(token);auto verifycontext=baseline_context(s);auto decoded=list(parsed.f[1],"MAA-bench/signatures",64);bool ok=parsed.f[0]==verifycontext&&decoded.size()==count;
 for(size_t i=0;i<count;i++){auto msg=periodic?frame("MAA-bench/periodic",{verifycontext}):frame("MAA-bench/attribute",{verifycontext,s.presented[i].occurrence,cached_cids[i]});ok=ok&&mld_verify(msg,decoded[i],keys[i]);}record(trial,periodic?"mldsa_periodic_verify":"mldsa_attribute_verify",elapsed(start),token.size(),ok);
 auto corrupted=sigs[0];corrupted[0]^=1;auto msg=periodic?frame("MAA-bench/periodic",{context}):frame("MAA-bench/attribute",{context,s.presented[0].occurrence,cached_cids[0]});require(!mld_verify(msg,corrupted,keys[0]),"baseline tamper accepted");
}
static RootInst authenticate_support(const SmokeState&s,uint64_t now){const auto&request=s.request;

  validate("manifest",s.manifest);validate("request",request);validate("dur-registration",s.dur);validate("setup-matrix",s.setup);
  auto man=parse(s.manifest).f,req=parse(request).f,dur=parse(s.dur).f,setup=parse(s.setup).f;


  require(man[0]==s.sid&&man[1]==s.param&&man[2]==s.pid&&value(man[3])==s.period&&value(man[8])>now,"manifest context/expiry");
  require(setup[0]==s.sid&&setup[1]==s.param,"setup context");
  require(mld_verify(s.dur,s.dur_sig,s.dur_key),"DUR authentication");require(dur[0]==s.sid&&dur[1]==s.param&&dur[2]==s.pid&&value(dur[3])==s.period&&value(dur[4])>=value(man[8])&&value(dur[4])>now,"DUR binding/expiry");
  require(value(req[6])==s.period&&sha(req[5])==man[4]&&req[5]==s.policy,"request policy/period");
  validate("witness",s.witness);auto ids=list(s.witness,"MAA-v1/witness",64);require(sha(s.witness)==man[5],"witness digest");std::set<Bytes>selected(ids.begin(),ids.end()),got;require(witness_ok(s.policy,selected,got)&&got==selected,"witness satisfaction");
  auto selected_obj=parse(man[6]);auto records=list(selected_obj.f[0],"MAA-v1/selected-records",64);require(records.size()==s.presented.size()&&records.size()==selected.size(),"record count");
  std::map<Bytes,Fields>leaves;policy_records(s.policy,leaves);std::map<Bytes,Fields>selections;for(const auto&x:records){auto f=parse(x).f;require(selected.count(f[0])&&selections.emplace(f[0],f).second,"selected witness");}
  for(const auto&rec:s.presented){
   validate("leaf",rec.leaf);validate("aa-root",rec.root);validate("status",rec.status);auto cr=parse(rec.credential).f,ro=parse(rec.root).f,st=parse(rec.status).f,lf=parse(rec.leaf).f;
   require(lf[0]==rec.credential,"leaf credential");auto cid=sha(rec.leaf);require(selections.count(rec.occurrence)&&leaves.count(rec.occurrence),"occurrence binding");auto sr=selections.at(rec.occurrence),pl=leaves.at(rec.occurrence);
   require(sr[1]==cid&&sr[2]==cr[2]&&sr[3]==ui(s.root_version,8)&&sr[4]==ui(s.status_version,8)&&sr[5]==ui(1,1),"selected snapshot");
   require(cr[0]==s.sid&&cr[1]==s.param&&cr[5]==s.pid&&cr[6]==ui(s.period,8)&&cr[8]==ui(s.root_version,8)&&value(cr[9])>=value(man[8])&&value(cr[9])>now,"credential context/expiry");
   require(cr[2]==pl[2]&&cr[3]==pl[3]&&cr[4]==pl[4],"attribute/issuer binding");
   require(mld_verify(rec.root,rec.root_sig,rec.issuer_key)&&mld_verify(rec.status,rec.status_sig,rec.issuer_key),"issuer authentication");
   require(ro[0]==s.sid&&ro[1]==s.param&&ro[2]==cr[2]&&ro[3]==ui(s.period,8)&&ro[4]==ui(s.root_version,8)&&verify_merkle(rec.opening,ro[5],value(ro[6]))&&parse(rec.opening).f[0]==cid&&value(ro[7])>=value(man[8])&&value(ro[7])>now,"Merkle root/opening binding");
   require(st[0]==s.sid&&st[1]==s.param&&st[2]==cr[2]&&st[3]==ui(s.period,8)&&st[4]==ui(s.status_version,8)&&st[5]==cid&&st[6]==ui(1,1)&&value(st[7])>=value(man[8])&&value(st[7])>now,"status binding");
  }
  auto coeff=ring(s.setup,D*D*N);MatU A(D,std::vector<PolyU>(D));size_t z=0;for(auto&r:A)for(auto&p:r)for(auto&x:p)x=coeff[z++];
  auto pub=public_root(A,s.presented);require(sha(enc("public-root",{s.sid,s.param,matrix_bytes(pub.Bpub)}))==man[7],"public root digest");
  return pub;
}

static void components(SmokeState&s,const RootInst&root,const EvalTW&te,const Schur&schur,DZ&dz,int trial){
 auto salt=random32();auto msg=enc("message",{s.sid,s.param,sha(s.manifest),s.payload,s.request,salt});auto u=target(msg);RecStats stats;
 auto a=Clock::now();auto perturb=sample_perturb(dz,te,schur,stats);auto perturb_ms=elapsed(a);
 a=Clock::now();auto mp=M_times_vec(root,perturb);std::vector<PolyU>v(D);for(int i=0;i<D;i++)for(int j=0;j<N;j++)v[i][j]=sub_mod(u[i][j],mp[i][j]);auto syndrome_ms=elapsed(a);
 a=Clock::now();auto z=module_gsample(dz,v);auto gadget_ms=elapsed(a);
 a=Clock::now();auto tz=T_times_z_exact(root.T,z);VecI e(ROOT_WIDTH);for(int i=0;i<M0;i++)for(int j=0;j<N;j++)e[i][j]=perturb[i][j]+tz[i][j];for(int i=0;i<W;i++)for(int j=0;j<N;j++)e[M0+i][j]=perturb[M0+i][j]+z[i][j];auto lift_ms=elapsed(a);
 auto token=enc("token",{s.sid,s.param,sha(s.manifest),salt,proof_bytes(e)});require(M_times_vec(root,e)==u,"component algebra");validate("token",token);
 record(trial,"component_perturb",perturb_ms,0,true);record(trial,"component_syndrome",syndrome_ms,0,true);record(trial,"component_gadget",gadget_ms,0,true);record(trial,"component_lift",lift_ms,0,true);
}
static Prepared pure_prepare(const SmokeState&s){auto pub=authenticate_support(s,uint64_t(std::time(nullptr)));return {std::move(pub),sha(s.manifest),s.sid,s.param,s.pid,s.policy,s.period,s.root_version,s.status_version,value(parse(s.manifest).f[8]),{}};}
static Bytes cold_sign(SmokeState&s,const MatU&A,const std::vector<Credential>&caps,DZ&dz,int trial,const std::string&prefix){
 auto total=Clock::now();auto pub=authenticate_support(s,uint64_t(std::time(nullptr)));reserve_preparation();
 require(caps.size()==s.presented.size(),"secret record count");
 for(size_t i=0;i<caps.size();i++){require(matrix_bytes(caps[i].Bpub)==parse(s.presented[i].credential).f[7],"private/public credential binding");}
 auto root=aggregate_credentials(A,caps,int(caps.size()));require(root.Bpub==pub.Bpub,"authenticated aggregate binding");require(exact_trapdoor_gate(root.T)&&verify_root_identity(root),"cold exact gate/identity");auto te=transform_T(root.T);require(aggregate_trapdoor_admissible(te,nullptr,admissibility_threshold()),"cold floating gate");auto schur=build_schur(te);auto prep_ms=elapsed(total);
 VecI proof;auto token=sign(s,root,te,schur,dz,proof);auto total_ms=elapsed(total);
 require(M_times_vec(root,proof)==target(enc("message",{s.sid,s.param,sha(s.manifest),s.payload,s.request,parse(token).f[3]})),"cold sign algebra");validate("token",token);
 record(trial,(prefix+"_prepare").c_str(),prep_ms,cold_support_bytes(s),true);record(trial,(prefix+"_total").c_str(),total_ms,token.size(),true);return token;
}
static void hook(SmokeState&s,const MatU&A,const std::vector<Credential>&caps,const RootInst&root,const EvalTW&te,const Schur&schur,std::mt19937_64&unused){
 auto saved_request=s.request;auto saved_consumed=s.consumed;auto seed=random32();auto sampler_seed=value(Bytes(seed.begin(),seed.begin()+8));std::mt19937_64 rng(sampler_seed);DZ dz(rng);std::ofstream(case_dir/"research_sampler_seed.txt")<<sampler_seed;
 // Evidence-authentication negatives exercise the new preparation path outside timers.
 auto must_reject=[&](const SmokeState&bad){bool rejected=false;try{pure_prepare(bad);}catch(const std::exception&){rejected=true;}require(rejected,"cold preparation tamper accepted");};
 {auto bad=s;bad.dur_sig[0]^=1;must_reject(bad);bad=s;bad.presented[0].root_sig[0]^=1;must_reject(bad);bad=s;bad.presented[0].status_sig[0]^=1;must_reject(bad);bad=s;bad.root_version++;must_reject(bad);}
 for(int i=-warmups;i<trials;i++){
  s.request=request(s);auto token=cold_sign(s,A,caps,dz,i,"signer_cold");
  auto start=Clock::now();auto prepared=pure_prepare(s);auto prepare_ms=elapsed(start);record(i,"verifier_prepare_pure",prepare_ms,cold_support_bytes(s),true);
  start=Clock::now();bool ok=prepared_verify(s,prepared,token);record(i,"supplement_prepared_verify",elapsed(start),token.size(),ok);require(!prepared_verify(s,prepared,token),"supplement replay");
  s.consumed.erase(parse(s.request).f[1]);require(smoke_verify(s,token,s.request,s.payload,uint64_t(std::time(nullptr))),"cold-sign independent verify");components(s,root,te,schur,dz,i);
 }
 auto digest=parse(s.manifest).f[7];
 for(int stage=0;stage<2;stage++)for(int i=-1;i<3;i++){
  SmokeState updated=s;auto before=support(updated);auto start=Clock::now();auto expiry=parse(updated.manifest).f[8];
  if(stage==0){updated.status_version++;for(auto&rec:updated.presented){auto f=parse(rec.status).f;f[4]=ui(updated.status_version,8);rec.status=enc("status",f);rec.status_sig=mld_sign(rec.status,rec.issuer_key,true);}}
  else{updated.root_version++;for(auto&rec:updated.presented){auto f=parse(rec.credential).f;f[8]=ui(updated.root_version,8);rec.credential=enc("credential",f);rec.leaf=enc("leaf",{rec.credential,random32()});}authenticate_issuer_trees(updated,0);}
  updated.manifest=make_manifest(updated,digest,expiry);auto update_ms=elapsed(start);auto bytes=changed_bytes(before,support(updated));std::string prefix=stage==0?"refresh_status":"refresh_root";record(i,(prefix+"_issuer_update").c_str(),update_ms,bytes,true);
  updated.request=request(updated);auto token=cold_sign(updated,A,caps,dz,i,prefix+"_cold_signer");
  start=Clock::now();auto fresh=pure_prepare(updated);record(i,(prefix+"_verifier_prepare_pure").c_str(),elapsed(start),bytes,true);require(prepared_verify(updated,fresh,token),"refresh new accepted");
  auto stale=pure_prepare(s);require(!prepared_verify(updated,stale,token),"refresh stale cache accepted");
 }
 s.request=saved_request;s.consumed=saved_consumed;
}
}
int main(int argc,char**argv){try{maa::require(argc==6,"usage: maa_benchmark matrix.csv output trials warmups round");bench::trials=std::stoi(argv[3]);bench::warmups=std::stoi(argv[4]);bench::round_id=std::stoi(argv[5]);maa::require(bench::trials>=1&&bench::warmups>=0,"sample counts");fs::path out=argv[2];fs::create_directories(out);bench::raw.open(out/"raw.csv");maa::require(bool(bench::raw),"raw output");bench::raw<<"round,case_id,trial,warmup,phase,ms,object_bytes,process_peak_working_set_bytes,ok\n";maa::benchmark_hook=bench::hook;std::ifstream matrix(argv[1]);maa::require(bool(matrix),"matrix input");std::string line;std::getline(matrix,line);int count=0;while(std::getline(matrix,line)){if(line.empty())continue;std::replace(line.begin(),line.end(),',',' ');std::istringstream row(line);int k,p;size_t leaves;maa::require(bool(row>>bench::case_id>>k>>p>>leaves),"matrix row");bench::case_dir=out/bench::case_id;std::cout<<"BENCH_BEGIN="<<bench::case_id<<std::endl;maa::lattice_smoke(k,bench::case_dir,p,leaves,false,false,false);count++;}std::cout<<"SUPPLEMENT_DRIVER=PASS cases="<<count<<" preparations="<<preparation_counter<<std::endl;return 0;}catch(const std::exception&e){std::cerr<<"BENCHMARK_FAIL: "<<e.what()<<std::endl;return 21;}}
