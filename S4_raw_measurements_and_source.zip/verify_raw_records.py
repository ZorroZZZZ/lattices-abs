"""Portable read-only check of the review dataset. Run after extraction.

Python standard library only. Recomputes process-level medians, 184 printed
table cells, two paired comparison ratios and the signing scaling ratio.
This is not a security proof checker or a full experiment rebuild script.
"""
from pathlib import Path
from collections import defaultdict
from statistics import median
import csv, json, hashlib

root = Path(__file__).resolve().parent
def rows(p):
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))
values = {}; receipts = {}
for batch, count, total, measured in [('scaling', 10, 73830, 63480), ('cold', 5, 14720, 11960)]:
    groups = defaultdict(list); allrows = []
    for rd in range(count):
        p = root / 'data' / batch / f'round_{rd:02d}' / 'raw.csv'
        records = rows(p); allrows.extend(records)
        receipts[str(p.relative_to(root)).replace('\\', '/')] = hashlib.sha256(p.read_bytes()).hexdigest()
        for x in records:
            assert x['ok'] == '1'
            if x['warmup'] == '0': groups[(rd, x['case_id'], x['phase'])].append(float(x['ms']))
    assert len(allrows) == total
    assert sum(x['warmup'] == '0' for x in allrows) == measured
    assert {int(x['object_bytes']) for x in allrows if x['phase'] in ['maa_online_sign', 'signer_cold_total']} == {78522}
    med = {k: median(v) for k, v in groups.items()}
    aggregate = defaultdict(list)
    for (rd, cid, phase), val in med.items(): aggregate[(cid, phase)].append(val)
    values[batch] = (med, {k: median(v) for k, v in aggregate.items()})
table = rows(root / 'audit/实验表格逐值复算.csv')
assert len(table) == 184
for row in table:
    batch = 'cold' if row['table'] == 'tab:supplement-cold' else 'scaling'
    value = values[batch][1][row['case'], row['phase']]
    assert f'{value:.3f}' == row['printed_ms'], row
med = values['scaling'][0]
for numerator, denominator, expected in [('maa_online_sign', 'mldsa_attribute_sign', '4.617'), ('maa_prepared_verify', 'mldsa_attribute_verify', '2.483')]:
    ratio = median(med[(rd, 'XD_K64', numerator)] / med[(rd, 'XD_K64', denominator)] for rd in range(10))
    assert f'{ratio:.3f}' == expected
ratio = median(med[(rd, 'XD_K64', 'maa_online_sign')] / med[(rd, 'XD_K01', 'maa_online_sign')] for rd in range(10))
assert f'{ratio:.4f}' == '1.0153'
manifest = json.loads((root / 'SHA256_MANIFEST.json').read_text(encoding='utf-8'))
for name, expected in manifest.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
print('PASS: raw counts, recorded checks, 184 table cells, paired ratios and archive member hashes.')
