"""Deterministic codec examples; dummy signatures are not valid ML-DSA signatures."""
import hashlib
import maa_codec as c

def examples():
    b=lambda x:bytes([x])*32
    context={'sid':b(1),'param_id':c.PARAM_ID}
    leaf_a={'kind':'leaf','occurrence':b(10),'issuer':'AA-1','namespace':'org','attribute':'role'}
    leaf_b={'kind':'leaf','occurrence':b(11),'issuer':'AA-2','namespace':'org','attribute':'device'}
    policy={'kind':'and','children':[leaf_a,leaf_b]}
    matrix=[i%c.Q for i in range(c.D*c.W*c.N)]
    credential={**context,'issuer':'AA-1','namespace':'org','attribute':'role','pid':b(2),'period':7,'matrix':matrix,'root_version':3,'expiry':2000000000}
    leaf={'credential':credential,'salt':b(3)}
    cid=c.digest('leaf',leaf)
    selected={'occurrence':b(10),'cid':cid,'issuer':'AA-1','root_version':3,'status_version':4,'status':1}
    witness=c.witness_encode([b(10),b(11)])
    root={'sid':b(1),'param_id':c.PARAM_ID,'matrix':matrix}
    manifest={**context,'pid':b(2),'period':7,'policy_hash':hashlib.sha256(c.field_encode('policy',leaf_a)).digest(),'witness_hash':hashlib.sha256(c.witness_encode([b(10)])).digest(),'selected':{'items':[selected]},'public_root_hash':c.digest('public-root',root),'expiry':2000000000}
    # Each object is a structural example, not a complete authorization transcript.
    request={'verifier':'PDP-1','nonce':b(4),'session':b(5),'resource':'/record','action':'read','policy':leaf_a,'period':7}
    dur={**context,'pid':b(2),'period':7,'expiry':2000000000,'dur_version':2}
    aa={**context,'issuer':'AA-1','period':7,'root_version':3,'root':cid,'leaf_count':1,'expiry':2000000000}
    status={**context,'issuer':'AA-1','period':7,'status_version':4,'cid':cid,'status':1,'expiry':2000000000}
    proof=[0]*c.PROOF_COUNT;proof[0]=1;proof[1]=-1
    data={'parameters':c.PROFILE,'setup-matrix':{**context,'seed':b(6)},'dur-registration':dur,'credential':credential,'leaf':leaf,'merkle-node':{'left':b(8),'right':b(9)},'merkle-empty':{**context,'issuer':'AA-1','period':7,'root_version':3},'aa-root':aa,'public-root':root,'selected':selected,'selected-list':{'items':[selected]},'status':status,'manifest':manifest,'request':request,'message':{**context,'wid':c.digest('manifest',manifest),'payload':b'example','request':request,'salt':b(7)},'token':{**context,'wid':c.digest('manifest',manifest),'salt':b(7),'proof':proof},'signed-dur':{'statement':dur,'signature':bytes(2420)},'signed-credential':{'statement':credential,'signature':bytes(2420)},'signed-root':{'statement':aa,'signature':bytes(2420)},'signed-status':{'statement':status,'signature':bytes(2420)},'opening':{'cid':cid,'leaf_index':0,'leaf_count':1,'siblings':[]}}
    return data,policy,witness
