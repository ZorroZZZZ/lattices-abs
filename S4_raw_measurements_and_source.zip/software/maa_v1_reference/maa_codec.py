"""MAA-v1 candidate reference codec. No trapdoor sampler or signature implementation."""
import hashlib
import struct
import unicodedata
from decimal import Decimal
from pathlib import Path
import json

Q = 17179859969
N, D, M0, W, HMAX = 256, 8, 16, 56, 64
PROOF_COUNT, PACK_BITS = (M0 + W) * N, 34
MAX_OBJECT = 4 * 1024 * 1024
MAX_FIELDS = 128
PROFILE = {
    'name': 'H64-research-1', 'hmax': HMAX, 'n': N, 'q': Q, 'd': D,
    'm0': M0, 'w': W, 'gadget_radix': 32, 'gadget_digits': 7,
    'pack_bits': PACK_BITS, 's_R': '2.0', 'alpha': '488.3263734200445',
    'zeta': '43346104.49987477', 'beta': '5884862290.537376',
    'preparation_budget': 2**28,
}
BETA = Decimal(PROFILE['beta'])
SCHEMAS = {
 'parameters': [('name','text'),('hmax','u32'),('n','u32'),('q','u64'),('d','u32'),('m0','u32'),('w','u32'),('gadget_radix','u32'),('gadget_digits','u32'),('pack_bits','u32'),('s_R','text'),('alpha','text'),('zeta','text'),('beta','text'),('preparation_budget','u64')],
 'setup-matrix': [('sid','b32'),('param_id','b32'),('seed','b32')],
 'dur-registration': [('sid','b32'),('param_id','b32'),('pid','b32'),('period','u64'),('expiry','u64'),('dur_version','u64')],
 'credential': [('sid','b32'),('param_id','b32'),('issuer','text'),('namespace','text'),('attribute','text'),('pid','b32'),('period','u64'),('matrix','public-matrix'),('root_version','u64'),('expiry','u64')],
 'leaf': [('credential','obj:credential'),('salt','b32')],
 'merkle-node': [('left','b32'),('right','b32')],
 'merkle-empty': [('sid','b32'),('param_id','b32'),('issuer','text'),('period','u64'),('root_version','u64')],
 'aa-root': [('sid','b32'),('param_id','b32'),('issuer','text'),('period','u64'),('root_version','u64'),('root','b32'),('leaf_count','u64'),('expiry','u64')],
 'public-root': [('sid','b32'),('param_id','b32'),('matrix','public-matrix')],
 'selected': [('occurrence','b32'),('cid','b32'),('issuer','text'),('root_version','u64'),('status_version','u64'),('status','u8')],
 'selected-list': [('items','list:selected')],
 'status': [('sid','b32'),('param_id','b32'),('issuer','text'),('period','u64'),('status_version','u64'),('cid','b32'),('status','u8'),('expiry','u64')],
 'manifest': [('sid','b32'),('param_id','b32'),('pid','b32'),('period','u64'),('policy_hash','b32'),('witness_hash','b32'),('selected','obj:selected-list'),('public_root_hash','b32'),('expiry','u64')],
 'request': [('verifier','text'),('nonce','b32'),('session','b32'),('resource','text'),('action','text'),('policy','policy'),('period','u64')],
 'message': [('sid','b32'),('param_id','b32'),('wid','b32'),('payload','payload'),('request','obj:request'),('salt','b32')],
 'token': [('sid','b32'),('param_id','b32'),('wid','b32'),('salt','b32'),('proof','proof')],
 'signed-dur': [('statement','obj:dur-registration'),('signature','signature')],
 'signed-credential': [('statement','obj:credential'),('signature','signature')],
 'signed-root': [('statement','obj:aa-root'),('signature','signature')],
 'signed-status': [('statement','obj:status'),('signature','signature')],
 'opening': [('cid','b32'),('leaf_index','u64'),('leaf_count','u64'),('siblings','hash-list')],
}

def framing(domain, fields):
    tag = domain.encode('ascii')
    if not 1 <= len(tag) <= 255 or len(fields) > MAX_FIELDS:
        raise ValueError('invalid framing domain/count')
    if any(type(f) is not bytes for f in fields):
        raise ValueError('fields must be bytes')
    size = 2 + len(tag) + 4 + sum(8 + len(f) for f in fields)
    if size > MAX_OBJECT:
        raise ValueError('object too large')
    return struct.pack('<H',len(tag))+tag+struct.pack('<I',len(fields))+b''.join(struct.pack('<Q',len(f))+f for f in fields)

def unframe(raw, expected_domain=None, expected_count=None):
    if type(raw) is not bytes or not 6 <= len(raw) <= MAX_OBJECT:
        raise ValueError('invalid object size')
    p=0
    def take(n):
        nonlocal p
        if n > len(raw)-p: raise ValueError('truncated object')
        v=raw[p:p+n]; p+=n; return v
    size=int.from_bytes(take(2),'little')
    if not 1 <= size <= 255: raise ValueError('domain size')
    try: tag=take(size).decode('ascii')
    except UnicodeError as e: raise ValueError('domain ASCII') from e
    count=int.from_bytes(take(4),'little')
    if count>MAX_FIELDS: raise ValueError('field count limit')
    if expected_domain is not None and tag!=expected_domain: raise ValueError('wrong domain/version')
    if expected_count is not None and count!=expected_count: raise ValueError('wrong field count')
    fields=[]
    for _ in range(count): fields.append(take(int.from_bytes(take(8),'little')))
    if p!=len(raw): raise ValueError('trailing bytes')
    return tag,fields

def uint(value,width):
    if type(value) is not int or not 0<=value<1<<(8*width): raise ValueError('integer range/type')
    return value.to_bytes(width,'little')

def text(value):
    if type(value) is not str: raise ValueError('text type')
    value=unicodedata.normalize('NFC',value)
    if not value or any(ord(c)<32 or 0x7f<=ord(c)<=0x9f for c in value): raise ValueError('empty/control text')
    try: raw=value.encode('utf-8')
    except UnicodeError as e: raise ValueError('invalid Unicode') from e
    if len(raw)>256: raise ValueError('text length')
    return raw

def text_decode(raw):
    try: v=raw.decode('utf-8')
    except UnicodeError as e: raise ValueError('invalid UTF-8') from e
    if text(v)!=raw: raise ValueError('noncanonical text')
    return v

def pack(values,bits,signed=False):
    if not 1<=bits<=64: raise ValueError('packing width')
    acc=used=0;out=bytearray()
    for x in values:
        if type(x) is not int: raise ValueError('coefficient type')
        z=(2*x if x>=0 else -2*x-1) if signed else x
        if not 0<=z<1<<bits: raise ValueError('coefficient packing range')
        acc|=z<<used;used+=bits
        while used>=8:
            out.append(acc&255);acc>>=8;used-=8
    if used: out.append(acc)
    return bytes(out)

def unpack(raw,count,bits,signed=False):
    if count<0 or not 1<=bits<=64 or len(raw)!=(count*bits+7)//8: raise ValueError('packed length')
    used_bits=count*bits
    if used_bits%8 and raw[-1]>>(used_bits%8): raise ValueError('nonzero padding')
    acc=used=p=0;out=[];mask=(1<<bits)-1
    for _ in range(count):
        while used<bits:
            acc|=raw[p]<<used;p+=1;used+=8
        z=acc&mask;acc>>=bits;used-=bits
        out.append((-(z+1)//2 if z&1 else z//2) if signed else z)
    return out

def public_matrix(values):
    if len(values)!=D*W*N or any(type(x) is not int or not 0<=x<Q for x in values): raise ValueError('matrix shape/range')
    return pack(values,Q.bit_length())

def check_proof(values):
    if len(values)!=PROOF_COUNT or any(type(x) is not int for x in values): raise ValueError('proof shape/type')
    # Integer arithmetic, no floating-point norm tolerance.
    numerator, denominator = BETA.as_integer_ratio()
    if sum(x*x for x in values)*denominator*denominator > numerator*numerator: raise ValueError('proof norm')
    return pack(values,PACK_BITS,True)

def list_encode(domain,items):
    return framing(domain,[uint(len(items),4),*items])

def list_decode(raw,domain,maximum):
    _,f=unframe(raw,domain)
    if not f or len(f[0])!=4: raise ValueError('list count')
    n=int.from_bytes(f[0],'little')
    if n>maximum or n!=len(f)-1: raise ValueError('list count/range')
    return f[1:]

def policy_encode(tree,depth=0):
    if depth>16: raise ValueError('policy depth')
    kind=tree.get('kind')
    if kind=='leaf':
        if set(tree)!={'kind','occurrence','issuer','namespace','attribute'}: raise ValueError('leaf fields')
        return framing('MAA-v1/policy-leaf',[uint(0,1),field_encode('b32',tree['occurrence']),text(tree['issuer']),text(tree['namespace']),text(tree['attribute'])])
    if kind not in ('and','or') or set(tree)!={'kind','children'} or len(tree['children'])!=2: raise ValueError('binary policy node')
    children=sorted(policy_encode(t,depth+1) for t in tree['children'])
    if children[0]==children[1]: raise ValueError('duplicate children')
    return framing('MAA-v1/policy-node',[uint(1 if kind=='and' else 2,1),*children])

def policy_decode(raw,depth=0):
    if depth>16: raise ValueError('policy depth')
    dom,f=unframe(raw)
    if dom=='MAA-v1/policy-leaf' and len(f)==5 and f[0]==b'\x00':
        return dict(kind='leaf',occurrence=field_decode('b32',f[1]),issuer=text_decode(f[2]),namespace=text_decode(f[3]),attribute=text_decode(f[4]))
    if dom!='MAA-v1/policy-node' or len(f)!=3 or f[0] not in (b'\x01',b'\x02') or f[1]>=f[2]: raise ValueError('policy node/order')
    return dict(kind='and' if f[0]==b'\x01' else 'or',children=[policy_decode(f[1],depth+1),policy_decode(f[2],depth+1)])

def policy_leaves(tree):
    if tree['kind']=='leaf': return [tree]
    return sum((policy_leaves(t) for t in tree['children']),[])

def validate_policy(tree):
    leaves=policy_leaves(tree)
    ids=[x['occurrence'] for x in leaves]
    if not 1<=len(leaves)<=64 or len(set(ids))!=len(ids): raise ValueError('policy leaf count/duplicate occurrence')

def witness_encode(ids):
    if not 1<=len(ids)<=64 or len(set(ids))!=len(ids): raise ValueError('witness count/duplicates')
    return list_encode('MAA-v1/witness',sorted(field_encode('b32',i) for i in ids))

def witness_decode(raw):
    ids=list_decode(raw,'MAA-v1/witness',64)
    if not ids or any(len(x)!=32 for x in ids) or ids!=sorted(set(ids)): raise ValueError('witness canonicality')
    return ids

def witness_satisfies(tree,ids):
    selected=set(ids)
    def walk(t):
        if t['kind']=='leaf': return {t['occurrence']} if t['occurrence'] in selected else None
        a,b=(walk(x) for x in t['children'])
        if t['kind']=='and': return None if a is None or b is None else a|b
        # Exactly one represented satisfying branch. The verifier does not know unused credentials.
        if (a is None)==(b is None): return None
        return a if a is not None else b
    got=walk(tree)
    return got is not None and got==selected

def field_encode(kind,v):
    if kind.startswith('u'): return uint(v,int(kind[1:])//8)
    if kind=='text': return text(v)
    if kind=='b32':
        if type(v) is not bytes or len(v)!=32: raise ValueError('32-byte field')
        return v
    if kind=='payload':
        if type(v) is not bytes or len(v)>1024*1024: raise ValueError('payload length/type')
        return v
    if kind=='signature':
        if type(v) is not bytes or len(v)!=2420: raise ValueError('ML-DSA-44 signature length')
        return v
    if kind=='public-matrix': return public_matrix(v)
    if kind=='proof': return check_proof(v)
    if kind=='policy':
        raw=policy_encode(v);validate_policy(policy_decode(raw));return raw
    if kind.startswith('obj:'): return encode(kind[4:],v)
    if kind=='list:selected':
        if not 1<=len(v)<=64: raise ValueError('selected count')
        records=sorted(v,key=lambda x:x['occurrence'])
        if len({x['occurrence'] for x in records})!=len(records) or len({x['cid'] for x in records})!=len(records): raise ValueError('duplicate selected credential/occurrence')
        return list_encode('MAA-v1/selected-records',[encode('selected',x) for x in records])
    if kind=='hash-list':
        if len(v)>32: raise ValueError('opening depth')
        return list_encode('MAA-v1/siblings',[field_encode('b32',x) for x in v])
    raise ValueError('unknown kind')

def field_decode(kind,raw):
    if kind.startswith('u'):
        if len(raw)!=int(kind[1:])//8: raise ValueError('integer width')
        return int.from_bytes(raw,'little')
    if kind=='text': return text_decode(raw)
    if kind in ('b32','payload','signature'): field_encode(kind,raw);return raw
    if kind=='public-matrix':
        v=unpack(raw,D*W*N,Q.bit_length());public_matrix(v);return v
    if kind=='proof':
        v=unpack(raw,PROOF_COUNT,PACK_BITS,True);check_proof(v);return v
    if kind=='policy': v=policy_decode(raw);validate_policy(v);return v
    if kind.startswith('obj:'): return decode(kind[4:],raw)
    if kind=='list:selected':
        v=[decode('selected',x) for x in list_decode(raw,'MAA-v1/selected-records',64)]
        if field_encode(kind,v)!=raw: raise ValueError('selected order')
        return v
    if kind=='hash-list': return [field_decode('b32',x) for x in list_decode(raw,'MAA-v1/siblings',32)]
    raise ValueError('unknown kind')

def validate(name,v):
    if 'param_id' in v and v['param_id']!=PARAM_ID: raise ValueError('unsupported parameters')
    if 'expiry' in v and v['expiry']==0: raise ValueError('zero expiry')
    if 'status' in v and v['status'] not in (0,1): raise ValueError('unknown status')
    if name=='parameters' and v!=PROFILE: raise ValueError('unsupported profile')
    if name=='aa-root' and not 0<=v['leaf_count']<=2**32: raise ValueError('tree size')
    if name=='opening':
        n=v['leaf_count'];i=v['leaf_index']
        if not 1<=n<=2**32 or not 0<=i<n or len(v['siblings'])!=(n-1).bit_length(): raise ValueError('opening size/index')
    if name=='selected-list' and any(x['status']!=1 for x in v['items']): raise ValueError('selected revoked credential')

def encode(name,values):
    schema=SCHEMAS.get(name)
    if schema is None or type(values) is not dict or set(values)!={n for n,k in schema}: raise ValueError('unknown schema/missing/extra fields')
    validate(name,values)
    return framing('MAA-v1/'+name,[field_encode(k,values[n]) for n,k in schema])

def decode(name,raw):
    if name not in SCHEMAS: raise ValueError('unknown schema')
    schema=SCHEMAS[name]
    _,f=unframe(raw,'MAA-v1/'+name,len(schema))
    v={n:field_decode(k,b) for (n,k),b in zip(schema,f)}
    validate(name,v)
    if encode(name,v)!=raw: raise ValueError('noncanonical object')
    return v

# Avoid a self-referential identifier: parameters have no param_id field.
PARAM_ID=hashlib.sha256(framing('MAA-v1/parameters',[field_encode(k,PROFILE[n]) for n,k in SCHEMAS['parameters']])).digest()

def digest(name,values): return hashlib.sha256(encode(name,values)).digest()

def map_words(words,count,q=Q):
    if type(count) is not int or count<0 or not 1<q<2**64: raise ValueError('mapping arguments')
    if count==0:return []
    limit=(2**64//q)*q;out=[]
    for word in words:
        if type(word) is not int or not 0<=word<2**64: raise ValueError('word range')
        if word<limit:out.append(word%q)
        if len(out)==count:return out
    raise ValueError('not enough accepted words')

def hash_to_ring(raw,count):
    if type(count) is not int or not 0<=count<=D*D*N: raise ValueError('coefficient count')
    if count==0:return []
    size=8*count
    while True:
        stream=hashlib.shake_256(raw).digest(size)
        words=(int.from_bytes(stream[i:i+8],'little') for i in range(0,size,8))
        try:return map_words(words,count)
        except ValueError:size*=2

def expand_setup(v):return hash_to_ring(encode('setup-matrix',v),D*D*N)
def message_target(v):return hash_to_ring(encode('message',v),D*N)

def merkle_root(leaves,empty=None):
    if not leaves:
        if empty is None:raise ValueError('empty tree context required')
        return digest('merkle-empty',empty)
    level=sorted(leaves)
    if any(type(x) is not bytes or len(x)!=32 for x in level) or len(set(level))!=len(level):raise ValueError('duplicate/invalid leaves')
    while len(level)>1:
        if len(level)%2:level.append(level[-1])
        level=[digest('merkle-node',{'left':level[i],'right':level[i+1]}) for i in range(0,len(level),2)]
    return level[0]

def verify_opening(v,root):
    validate('opening',v)
    x=v['cid'];idx=v['leaf_index'];width=v['leaf_count']
    for sib in v['siblings']:
        if idx%2==0 and idx+1>=width and sib!=x:return False
        x=digest('merkle-node',{'left':sib,'right':x} if idx&1 else {'left':x,'right':sib})
        idx//=2;width=(width+1)//2
    return x==root

if __name__=='__main__':
    print('MAA-v1 candidate H64 param_id='+PARAM_ID.hex())
