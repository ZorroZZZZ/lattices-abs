"""Generate full encoding files and a compact SHA-256/SHAKE manifest."""
from pathlib import Path
import hashlib,json
import maa_codec as c
from examples import examples
r=Path(__file__).parent;out=r/'vectors';out.mkdir(exist_ok=True)
data,policy,witness=examples();manifest=[]
for name,v in data.items():
    raw=c.encode(name,v)
    if c.encode(name,c.decode(name,raw))!=raw:raise RuntimeError('roundtrip '+name)
    (out/(name+'.bin')).write_bytes(raw)
    item={'name':name,'file':name+'.bin','length':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'shake256_32':hashlib.shake_256(raw).hexdigest(32)}
    if name in ('message','setup-matrix'):
        item['ring_prefix_8']=c.hash_to_ring(raw,8)
        count=c.D*c.N if name=='message' else c.D*c.D*c.N
        item['ring_output_count']=count
        item['ring_output_u64le_sha256']=hashlib.sha256(b''.join(x.to_bytes(8,'little') for x in c.hash_to_ring(raw,count))).hexdigest()
    manifest.append(item)
for name,raw in [('policy',c.field_encode('policy',policy)),('witness',witness)]:
    (out/(name+'.bin')).write_bytes(raw)
    manifest.append({'name':name,'file':name+'.bin','length':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'shake256_32':hashlib.shake_256(raw).hexdigest(32)})
(out/'manifest.json').write_text(json.dumps({'status':'candidate-reference-v1','param_id':c.PARAM_ID.hex(),'examples':'examples.py; structural vectors, dummy signatures, not a valid transcript','vectors':manifest},indent=2),encoding='utf-8')
print('GENERATED',len(manifest),'vectors; token bytes',len(c.encode('token',data['token'])))
