import unittest,hashlib,json,struct
from pathlib import Path
import maa_codec as c
from examples import examples

class CodecTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.data,cls.policy,cls.witness=examples()
    def test_all_objects_roundtrip(self):
        for name,v in self.data.items():
            with self.subTest(name=name):
                raw=c.encode(name,v);self.assertEqual(c.encode(name,c.decode(name,raw)),raw)
    def test_legacy_vectors(self):
        f=Path(__file__).resolve().parents[1]/'revision_current/serialization_test_vectors.json'
        for v in json.loads(f.read_text(encoding='utf-8'))['vectors']:
            raw=c.framing(v['domain_utf8'],[bytes.fromhex(x) for x in v['fields_hex']])
            self.assertEqual(raw.hex(),v['encoded_hex']);self.assertEqual(hashlib.shake_256(raw).hexdigest(32),v['shake256_32_hex'])
            if 'first_8_coefficients' in v:self.assertEqual(c.hash_to_ring(raw,8),v['first_8_coefficients'])
    def test_rejection_threshold(self):
        limit=(2**64//c.Q)*c.Q
        self.assertEqual(c.map_words([limit,2**64-1,limit-1,0,c.Q],3),[c.Q-1,0,0])
    def test_rejection_exhaustion(self):
        with self.assertRaises(ValueError):c.map_words([2**64-1],1)
    def test_unknown_domain(self):
        raw=c.encode('dur-registration',self.data['dur-registration'])
        with self.assertRaises(ValueError):c.decode('status',raw)
    def test_missing_extra_field(self):
        for v in [{'sid':bytes(32)},{**self.data['setup-matrix'],'extra':b''}]:
            with self.assertRaises(ValueError):c.encode('setup-matrix',v)
    def test_truncation_and_trailing(self):
        raw=c.encode('setup-matrix',self.data['setup-matrix'])
        for v in [raw[:-1],raw+b'\0',raw[:1]]:
            with self.assertRaises(ValueError):c.decode('setup-matrix',v)
    def test_huge_declared_length(self):
        raw=c.framing('MAA-v1/setup-matrix',[bytes(32)]*3)
        offset=2+len('MAA-v1/setup-matrix')+4
        raw=raw[:offset]+struct.pack('<Q',2**64-1)+raw[offset+8:]
        with self.assertRaises(ValueError):c.decode('setup-matrix',raw)
    def test_wrong_count(self):
        with self.assertRaises(ValueError):c.decode('setup-matrix',c.framing('MAA-v1/setup-matrix',[bytes(32)]))
    def test_wrong_uint_width(self):
        raw=c.encode('dur-registration',self.data['dur-registration']);tag,f=c.unframe(raw);f[3]=b'\x07'
        with self.assertRaises(ValueError):c.decode('dur-registration',c.framing(tag,f))
    def test_unknown_parameters(self):
        with self.assertRaises(ValueError):c.encode('setup-matrix',{**self.data['setup-matrix'],'param_id':bytes(32)})
    def test_integer_range(self):
        for x in [-1,2**64,True]:
            with self.assertRaises(ValueError):c.uint(x,8)
    def test_unicode_nfc(self):
        self.assertEqual(c.text('e\u0301'),c.text('\u00e9'))
        with self.assertRaises(ValueError):c.text_decode('e\u0301'.encode())
    def test_utf8_and_text_limits(self):
        for raw in [b'\xff',b'',b'a\0b',b'a'*257]:
            with self.assertRaises(ValueError):c.text_decode(raw)
    def test_matrix_q_rejected(self):
        x=list(self.data['credential']['matrix']);x[0]=c.Q
        with self.assertRaises(ValueError):c.public_matrix(x)
        raw=c.pack(x,c.Q.bit_length())
        with self.assertRaises(ValueError):c.field_decode('public-matrix',raw)
    def test_zigzag_edges(self):
        x=[-8,7,0,-1,1];raw=c.pack(x,4,True);self.assertEqual(c.unpack(raw,len(x),4,True),x)
        with self.assertRaises(ValueError):c.pack([8],4,True)
    def test_nonzero_padding(self):
        with self.assertRaises(ValueError):c.unpack(b'\xf0',1,4)
    def test_proof_norm_boundary(self):
        x=[0]*c.PROOF_COUNT;x[0]=int(c.BETA);self.assertEqual(len(c.check_proof(x)),78336)
        x[0]+=1
        with self.assertRaises(ValueError):c.check_proof(x)
    def test_proof_length(self):
        with self.assertRaises(ValueError):c.field_decode('proof',b'\0')
    def test_policy_order(self):
        reverse={**self.policy,'children':list(reversed(self.policy['children']))}
        self.assertEqual(c.field_encode('policy',self.policy),c.field_encode('policy',reverse))
        raw=c.field_encode('policy',self.policy);tag,f=c.unframe(raw);f[1],f[2]=f[2],f[1]
        with self.assertRaises(ValueError):c.field_decode('policy',c.framing(tag,f))
    def test_duplicate_occurrence(self):
        a,b=self.policy['children'];b={**b,'occurrence':a['occurrence']}
        with self.assertRaises(ValueError):c.field_encode('policy',{'kind':'and','children':[a,b]})
    def test_witness_duplicates_and_order(self):
        ids=[x['occurrence'] for x in self.policy['children']]
        self.assertEqual(c.witness_encode(list(reversed(ids))),self.witness)
        with self.assertRaises(ValueError):c.witness_encode([ids[0],ids[0]])
        with self.assertRaises(ValueError):c.witness_decode(c.list_encode('MAA-v1/witness',list(reversed(ids))))
    def test_policy_satisfaction(self):
        ids=[x['occurrence'] for x in self.policy['children']]
        self.assertTrue(c.witness_satisfies(self.policy,ids));self.assertFalse(c.witness_satisfies(self.policy,ids[:1]))
        t={**self.policy,'kind':'or'}
        self.assertTrue(c.witness_satisfies(t,ids[:1]));self.assertFalse(c.witness_satisfies(t,ids))
    def test_selected_duplicates(self):
        x=self.data['selected']
        with self.assertRaises(ValueError):c.encode('selected-list',{'items':[x,x]})
    def test_revoked_selected(self):
        with self.assertRaises(ValueError):c.encode('selected-list',{'items':[{**self.data['selected'],'status':0}]})
    def test_status_enum(self):
        with self.assertRaises(ValueError):c.encode('status',{**self.data['status'],'status':2})
    def test_empty_tree(self):
        ctx=self.data['merkle-empty'];self.assertEqual(c.merkle_root([],ctx),c.digest('merkle-empty',ctx))
        with self.assertRaises(ValueError):c.merkle_root([])
    def test_merkle_three_and_opening(self):
        a,b,d=[bytes([i])*32 for i in (1,2,3)]
        ab=c.digest('merkle-node',{'left':a,'right':b});dd=c.digest('merkle-node',{'left':d,'right':d})
        root=c.digest('merkle-node',{'left':ab,'right':dd})
        self.assertEqual(c.merkle_root([d,a,b]),root)
        v={'cid':d,'leaf_index':2,'leaf_count':3,'siblings':[d,ab]}
        self.assertTrue(c.verify_opening(v,root));self.assertFalse(c.verify_opening({**v,'siblings':[a,ab]},root))
    def test_merkle_duplicate(self):
        with self.assertRaises(ValueError):c.merkle_root([bytes(32)]*2)
    def test_opening_bounds(self):
        for v in [{'cid':bytes(32),'leaf_index':1,'leaf_count':1,'siblings':[]},{'cid':bytes(32),'leaf_index':0,'leaf_count':3,'siblings':[]}]:
            with self.assertRaises(ValueError):c.encode('opening',v)
    def test_payload_length(self):
        with self.assertRaises(ValueError):c.field_encode('payload',bytes(1024*1024+1))
    def test_signature_size(self):
        with self.assertRaises(ValueError):c.field_encode('signature',bytes(2419))
    def test_token_size(self):self.assertEqual(len(c.encode('token',self.data['token'])),78522)
    def test_hash_binding(self):
        msg=self.data['message'];changed={**msg,'payload':b'changed'}
        self.assertNotEqual(c.message_target(msg),c.message_target(changed))
        self.assertEqual(len(c.message_target(msg)),2048)
        self.assertEqual(len(c.expand_setup(self.data['setup-matrix'])),16384)

if __name__=='__main__':unittest.main(verbosity=2)
