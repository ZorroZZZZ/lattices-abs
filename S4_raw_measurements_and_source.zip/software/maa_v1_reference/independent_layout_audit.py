"""Independent byte-layout inspection; intentionally does not import maa_codec."""
from pathlib import Path
import json,hashlib
Q=17179859969
r=Path(__file__).parent/'vectors'
m=json.loads((r/'manifest.json').read_text())

def read(raw):
    p=0
    def take(n):
        nonlocal p
        if n>len(raw)-p:raise RuntimeError('truncated vector')
        x=raw[p:p+n];p+=n;return x
    tag=take(int.from_bytes(take(2),'little')).decode('ascii')
    count=int.from_bytes(take(4),'little')
    fields=[take(int.from_bytes(take(8),'little')) for _ in range(count)]
    if p!=len(raw):raise RuntimeError('trailing vector')
    rebuilt=len(tag).to_bytes(2,'little')+tag.encode()+len(fields).to_bytes(4,'little')+b''.join(len(x).to_bytes(8,'little')+x for x in fields)
    if rebuilt!=raw:raise RuntimeError('layout mismatch')
    return tag,fields

for item in m['vectors']:
    raw=(r/item['file']).read_bytes();tag,fields=read(raw)
    expected = 'MAA-v1/policy-node' if item['name']=='policy' else 'MAA-v1/'+item['name']
    if tag!=expected:raise RuntimeError('domain mismatch')
    if len(raw)!=item['length'] or hashlib.sha256(raw).hexdigest()!=item['sha256'] or hashlib.shake_256(raw).hexdigest(32)!=item['shake256_32']:raise RuntimeError('digest mismatch')
    if 'ring_prefix_8' in item:
        stream=hashlib.shake_256(raw).digest(256);limit=(2**64//Q)*Q
        coeff=[]
        for j in range(0,len(stream),8):
            x=int.from_bytes(stream[j:j+8],'little')
            if x<limit:coeff.append(x%Q)
        if coeff[:8]!=item['ring_prefix_8']:raise RuntimeError('mapping mismatch')
    print('PASS',item['name'],len(raw))
# Inspect every public-matrix coefficient using independent unaligned bit extraction.
_,fields=read((r/'credential.bin').read_bytes());matrix=fields[7]
for i in range(8*56*256):
    bit=i*34;pos=bit//8;shift=bit%8
    value=(int.from_bytes(matrix[pos:pos+6],'little')>>shift)&((1<<34)-1)
    if value!=i:raise RuntimeError('matrix coefficient/order mismatch')
_,fields=read((r/'token.bin').read_bytes());proof=fields[4]
for i in range(72*256):
    bit=i*34;pos=bit//8;shift=bit%8
    z=(int.from_bytes(proof[pos:pos+6],'little')>>shift)&((1<<34)-1)
    expected=2 if i==0 else 1 if i==1 else 0
    if z!=expected:raise RuntimeError('proof ZigZag/order mismatch')
print('PASS independent_matrix_coefficients=114688')
print('PASS independent_proof_coefficients=18432')
# Seed streams checked across the complete required coefficient output.
for name,count in [('setup-matrix',8*8*256),('message',8*256)]:
    raw=(r/(name+'.bin')).read_bytes();stream=hashlib.shake_256(raw).digest(8*(count+1024));limit=(2**64//Q)*Q
    values=[int.from_bytes(stream[i:i+8],'little')%Q for i in range(0,len(stream),8) if int.from_bytes(stream[i:i+8],'little')<limit][:count]
    if len(values)!=count:raise RuntimeError('insufficient stream')
    # Persist output digest for the future C++ comparison; u64 per output coefficient.
    digest=hashlib.sha256(b''.join(x.to_bytes(8,'little') for x in values)).hexdigest()
    entry=next(x for x in m['vectors'] if x['name']==name)
    if entry['ring_output_count']!=count or entry['ring_output_u64le_sha256']!=digest:raise RuntimeError('full ring output mismatch')
    print('PASS',name,'full_output_count='+str(count),'u64le_output_sha256='+digest)
print('INDEPENDENT_LAYOUT_AUDIT=PASS')
