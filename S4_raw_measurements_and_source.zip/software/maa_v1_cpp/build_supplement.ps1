$ErrorActionPreference='Stop'
$Root=$PSScriptRoot
$ReferenceBuild=(Get-Content -LiteralPath (Join-Path $Root 'latest_successful_build.txt') -Raw).Trim()
$Library=Join-Path $ReferenceBuild 'mldsa-native-2.0.0'
$Build=Join-Path $Root ('supplement_build_'+(Get-Date -Format 'yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Path $Build | Out-Null
$Vs='D:\codex\tools\VS2022BuildTools\Common7\Tools\VsDevCmd.bat'
$Cpp=Join-Path $Root 'maa_supplement.cpp'
$Exe=Join-Path $Build 'maa_supplement.exe'
$Obj=Join-Path $Build 'maa_supplement.obj'
$Compile='cl /nologo /O2 /utf-8 /std:c++17 /EHsc /D MLD_CONFIG_NO_RANDOMIZED_API /D MLD_CONFIG_PARAMETER_SET=44 /D STAGE13C_PROFILE_HMAX=64 /Imldsa /Imldsa/src /Imldsa/src/fips202 /Imldsa/src/fips202/native /Imldsa/src/native /Fo"'+$Obj+'" /Fe"'+$Exe+'" "'+$Cpp+'" test\build\mldsa44\mldsa\*.obj test\build\mldsa44\mldsa\fips202\*.obj /link bcrypt.lib psapi.lib normaliz.lib'
$Cmd=@('@echo off',"call `"$Vs`" -arch=x64 -host_arch=x64",'if errorlevel 1 exit /b %errorlevel%',"cd /d `"$Library`"",$Compile,'exit /b %errorlevel%')
Set-Content -LiteralPath (Join-Path $Build 'compile.cmd') -Value $Cmd -Encoding ASCII
$ErrorActionPreference='Continue'
& cmd.exe /d /c (Join-Path $Build 'compile.cmd') *> (Join-Path $Build 'compile.log')
$CompileExit=$LASTEXITCODE
$ErrorActionPreference='Stop'
if($CompileExit -ne 0){Get-Content -LiteralPath (Join-Path $Build 'compile.log') -Tail 35;throw 'Benchmark build failed'}
$Files=@($Cpp,(Join-Path $Root 'maa_profile.cpp'),(Join-Path $Root 'schema_generated.h'),$Exe)
$Files+=@(Get-ChildItem -LiteralPath (Join-Path $Library 'test/build/mldsa44/mldsa') -File -Filter '*.obj' | Select-Object -ExpandProperty FullName)
$Files+=@(Get-ChildItem -LiteralPath (Join-Path $Library 'test/build/mldsa44/mldsa/fips202') -File -Filter '*.obj' | Select-Object -ExpandProperty FullName)
$Hashes=@{};foreach($File in $Files){$Hashes[$File]=(Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash.ToLowerInvariant()}
$Hashes | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $Build 'SOURCE_AND_BINARY_SHA256.json') -Encoding UTF8
$Snapshot=Join-Path $Build 'source_snapshot';New-Item -ItemType Directory -Path $Snapshot | Out-Null
Copy-Item -LiteralPath $Cpp,(Join-Path $Root 'maa_profile.cpp'),(Join-Path $Root 'schema_generated.h') -Destination $Snapshot
$Exe | Set-Content -LiteralPath (Join-Path $Root 'latest_supplement_executable.txt') -Encoding ASCII
Write-Output ('BENCHMARK_BUILD_PASS='+$Exe)
