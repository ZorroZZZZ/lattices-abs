$ErrorActionPreference='Stop'
$Root=$PSScriptRoot
$Transfer=Split-Path $Root
$Zip=Join-Path $Transfer 'stage13c_frozen/third_party/mldsa-native-v2.0.0.zip'
if((Get-FileHash -LiteralPath $Zip -Algorithm SHA256).Hash.ToLowerInvariant() -ne 'c201a7a8467afa5b072ca3007cf91ebb55dd027a8f1dc876adcae3a6ccc8b158'){throw 'Pinned dependency hash mismatch'}
$env:TEMP='D:\codex\tmp';$env:TMP=$env:TEMP
$Stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$Build=Join-Path $Root ('build_'+$Stamp)
New-Item -ItemType Directory -Path $Build | Out-Null
Expand-Archive -LiteralPath $Zip -DestinationPath $Build
$Src=Join-Path $Build 'mldsa-native-2.0.0'
$Base=Get-Content -LiteralPath (Join-Path $Src 'Makefile.Microsoft_nmake') -Raw
$Base=$Base.Replace('CFLAGS = /nologo /O2','CFLAGS = /nologo /O2 /utf-8 /D MLD_CONFIG_NO_RANDOMIZED_API')
$TargetLines=@()
$TargetLines+=''
$TargetLines+='maa_profile: $(OBJ_FILES_44)'
$TargetLines+=("`t"+'$(CC) $(CFLAGS) /std:c++17 /EHsc /D MLD_CONFIG_PARAMETER_SET=44 /D STAGE13C_PROFILE_HMAX=64 /c /Fo$(MLDSA44_BUILD_DIR)\maa_profile.obj "'+(Join-Path $Root 'maa_profile.cpp')+'"')
$TargetLines+=("`t"+'@if NOT EXIST $(MLDSA44_BUILD_DIR)\bin mkdir $(MLDSA44_BUILD_DIR)\bin')
$TargetLines+=("`t"+'$(CC) /nologo /O2 /EHsc /Fe$(MLDSA44_BUILD_DIR)\bin\maa_profile.exe $(OBJ_FILES_44) $(MLDSA44_BUILD_DIR)\maa_profile.obj /link bcrypt.lib psapi.lib normaliz.lib')
$Target=$TargetLines -join "`r`n"

Set-Content -LiteralPath (Join-Path $Src 'Makefile.MAA') -Value ($Base+$Target) -Encoding ASCII
$Vs='D:\codex\tools\VS2022BuildTools\Common7\Tools\VsDevCmd.bat'
$Cmd=@('@echo off',"call `"$Vs`" -arch=x64 -host_arch=x64",'if errorlevel 1 exit /b %errorlevel%',"cd /d `"$Src`"",'nmake /nologo /f Makefile.MAA maa_profile','exit /b %errorlevel%')
Set-Content -LiteralPath (Join-Path $Build 'compile.cmd') -Value $Cmd -Encoding ASCII
$ErrorActionPreference='Continue'
& cmd.exe /d /c (Join-Path $Build 'compile.cmd') *> (Join-Path $Build 'compile.log')
$CompileExit=$LASTEXITCODE
$ErrorActionPreference='Stop'
if($CompileExit -ne 0){Get-Content -LiteralPath (Join-Path $Build 'compile.log') -Tail 40;throw 'C++ build failed'}
$Exe=Join-Path $Src 'test/build/mldsa44/bin/maa_profile.exe'
$Output=Join-Path $Build 'outputs'
$ErrorActionPreference='Continue'
& $Exe (Join-Path $Transfer 'maa_v1_reference/vectors') $Output (Join-Path $Root 'correctness_matrix.csv') *> (Join-Path $Build 'validation.log')
$ValidationExit=$LASTEXITCODE
$ErrorActionPreference='Stop'
Get-Content -LiteralPath (Join-Path $Build 'validation.log')
if($ValidationExit -ne 0){throw 'C++ validation failed'}
$Build | Set-Content -LiteralPath (Join-Path $Root 'latest_successful_build.txt') -Encoding ASCII
Write-Output ('BUILD_AND_VALIDATION_PASS='+$Build)
