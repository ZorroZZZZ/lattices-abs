"""Check C++ output in Python; independently evaluate all lattice ring relations."""
from pathlib import Path
import sys,json,hashlib
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'maa_v1_reference'))
import maa_codec as c
B=Path((Path(__file__).parent/'latest_successful_build.txt').read_text().strip())
out=B/'outputs';reference=R/'maa_v1_reference/vectors'
manifest=json.loads((reference/'manifest.json').read_text())
for v in manifest['vectors']:
    raw=(out/v['file']).read_bytes()
    if raw!=(reference/v['file']).read_bytes():raise RuntimeError('bytes differ '+v['name'])
    if v['name'] in ('policy','witness'):
        c.field_decode('policy',raw) if v['name']=='policy' else c.witness_decode(raw)
    else:c.decode(v['name'],raw)
    if v['name'] in ('setup-matrix','message'):
        data=(out/(v['name']+'-ring.bin')).read_bytes()
        if len(data)!=8*v['ring_output_count'] or hashlib.sha256(data).hexdigest()!=v['ring_output_u64le_sha256']:raise RuntimeError('ring output mismatch')
print('PYTHON_CPP_VECTOR_CROSSCHECK=PASS vectors=23 full_setup_and_message_outputs=PASS')
for name in ['signed-dur','signed-root','signed-status']:
    obj=c.decode(name,(out/(name+'-real.bin')).read_bytes())
    if not any(obj['signature']):raise RuntimeError('dummy signature remains')
print('REAL_SIGNATURE_WRAPPERS_DECODE=PASS cryptographic_verification=performed_by_CPP')

# Independent recursive transform, no call into the C++ lattice implementation.
q,n=c.Q,c.N
psi=next(pow(a,(q-1)//(2*n),q) for a in range(2,10000) if pow(pow(a,(q-1)//(2*n),q),n,q)==q-1)
omega=psi*psi%q
twist=[pow(psi,i,q) for i in range(n)]
def fft(a,w):
    if len(a)==1:return a
    ev=fft(a[::2],w*w%q);od=fft(a[1::2],w*w%q);half=len(a)//2
    factors=[pow(w,i,q) for i in range(half)]
    return [(ev[i]+factors[i]*od[i])%q for i in range(half)]+[(ev[i]-factors[i]*od[i])%q for i in range(half)]
def transform(a):return fft([x*t%q for x,t in zip(a,twist)],omega)
def poly_blocks(coeff):return [coeff[i:i+n] for i in range(0,len(coeff),n)]

folders=[out/x for x in ["smoke_k1","smoke_k2","smoke_multileaf_or","case_XD_K64","case_SINGLE_K64","case_FW64_J08"]]
for folder in folders:
    k=len(list(folder.glob("issuer_*")))
    obj={name:c.decode(name,(folder/(name+'.bin')).read_bytes()) for name in ['setup-matrix','dur-registration','manifest','request','message','token','public-root']}
    token,msg,man,req=obj['token'],obj['message'],obj['manifest'],obj['request']
    policy=c.field_decode('policy',(folder/'policy.bin').read_bytes());ids=c.witness_decode((folder/'witness.bin').read_bytes())
    if not c.witness_satisfies(policy,ids):raise RuntimeError('witness mismatch')
    if c.digest('manifest',man)!=token['wid'] or msg['wid']!=token['wid'] or msg['salt']!=token['salt'] or c.encode('request',msg['request'])!=c.encode('request',req):raise RuntimeError('request/message/manifest mismatch')
    if man['policy_hash']!=hashlib.sha256(c.field_encode('policy',policy)).digest() or man['witness_hash']!=hashlib.sha256(c.witness_encode(ids)).digest():raise RuntimeError('policy/witness hash mismatch')
    public=[0]*(c.D*c.W*n)
    records={x['occurrence']:x for x in man['selected']['items']}
    for i in range(1,k+1):
        issuer=folder/f'issuer_{i}'
        cred=c.decode('credential',(issuer/'credential.bin').read_bytes());leaf=c.decode('leaf',(issuer/'leaf.bin').read_bytes())
        root=c.decode('signed-root',(issuer/'signed-root.bin').read_bytes())['statement'];status=c.decode('signed-status',(issuer/'signed-status.bin').read_bytes())['statement']
        cid=c.digest('leaf',leaf)
        opening=c.decode('opening',(issuer/'opening.bin').read_bytes())
        if c.encode('credential',leaf['credential'])!=c.encode('credential',cred) or opening['cid']!=cid or opening['leaf_count']!=root['leaf_count'] or not c.verify_opening(opening,root['root']) or status['cid']!=cid or status['status']!=1:raise RuntimeError('credential root/status mismatch')
        if cred['sid']!=man['sid'] or cred['param_id']!=man['param_id'] or cred['pid']!=man['pid'] or cred['period']!=man['period']:raise RuntimeError('credential context mismatch')
        rec=next(x for x in records.values() if x['cid']==cid)
        if rec['issuer']!=cred['issuer'] or rec['root_version']!=root['root_version'] or rec['status_version']!=status['status_version']:raise RuntimeError('record state mismatch')
        public=[(x+y)%q for x,y in zip(public,cred['matrix'])]
    for i in range(c.D):
        for j in range(7):
            ix=(i*c.W+i*7+j)*n
            public[ix]=(public[ix]-(k-1)*32**j)%q
    if public!=obj['public-root']['matrix'] or c.digest('public-root',obj['public-root'])!=man['public_root_hash']:raise RuntimeError('aggregate public root mismatch')
    ahat=poly_blocks(c.expand_setup(obj['setup-matrix']));bs=poly_blocks(public);proof=poly_blocks(token['proof']);target=poly_blocks(c.message_target(msg))
    at=[transform(a) for a in ahat];bt=[transform(b) for b in bs];et=[transform(e) for e in proof];ut=[transform(u) for u in target]
    for row in range(c.D):
        for j in range(n):
            lhs=(sum(at[row*c.D+h][j]*et[h][j] for h in range(c.D))+et[c.D+row][j]+sum(bt[row*c.W+h][j]*et[c.M0+h][j] for h in range(c.W)))%q
            if lhs!=ut[row][j]:raise RuntimeError('independent lattice equation mismatch')
    print(f'PYTHON_LATTICE_TRANSCRIPT_{folder.name}_K{k}=PASS matrix_reconstruction=PASS all_2048_ring_equations=PASS token_bytes={len((folder/"token.bin").read_bytes())}')
import csv
rows=[]
for folder in sorted(out.glob('case_*')):
    row=next(csv.DictReader((folder/'case_summary.csv').open()))
    if int(row['token_bytes'])!=78522:raise RuntimeError('matrix token bytes')
    rows.append(dict(case_id=folder.name[5:],**row))
if len(rows)!=23:raise RuntimeError('matrix incomplete')
roots={hashlib.sha256((folder/'public-root.bin').read_bytes()).hexdigest() for folder in out.glob('case_FW64_*')}
if len(roots)!=1:raise RuntimeError('fixed witness partition changed root')
with (B/'correctness_matrix_results.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print('MATRIX_RECEIPTS=PASS cases=23 fixed_witness_root_invariance=PASS')
print('CROSS_LANGUAGE_AND_LATTICE_AUDIT=PASS')
